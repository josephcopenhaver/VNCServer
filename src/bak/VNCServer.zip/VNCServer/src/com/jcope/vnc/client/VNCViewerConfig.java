package com.jcope.vnc.client;



public class VNCViewerConfig {
	public static final String serverAddress = "127.0.0.1";
	public static final int serverPort = 4444;
	public static final long refreshMS = 1000;
}