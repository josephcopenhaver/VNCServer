package com.jcope.vnc.server;

import java.net.UnknownHostException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileLock;
import java.io.RandomAccessFile;

import com.jcope.util.CurrentProcessInfo;
import com.jcope.util.Platform;



public class VNCServer {
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		RandomAccessFile serverFileRAF = null;
		FileLock serverFileLock = null;
		RandomAccessFile pidFileRAF = null;
		FileLock pidFileLock = null;
		FileOutputStream pidFileFOS = null;
		try {
			
			
			// begin single instance logic!
			
			
			File serverLockFile = new File("server.lock");
			if (serverLockFile.exists()) {
				throw new RuntimeException("Server already running (server lock file exists)");
			}
			serverFileRAF = new RandomAccessFile(serverLockFile, "rw");
			serverFileLock = serverFileRAF.getChannel().tryLock();
			if (serverFileLock == null) {
				throw new RuntimeException("Server already running (cannot acquire server instance lock file)");
			}
			serverLockFile.deleteOnExit();
			File pidFile = new File("server.pid");
			if (pidFile.exists()) {
				throw new RuntimeException("Server already running (pid file exists)");
			}
			pidFileRAF = new RandomAccessFile(pidFile, "rw");
			pidFileLock = pidFileRAF.getChannel().tryLock();
			if (pidFileLock == null) {
				throw new RuntimeException("Server already running (cannot lock pid file)");
			}
			pidFile.deleteOnExit();
			if (Platform.isWindows())
			{
				pidFileLock.release();
				pidFileLock = null;
			}
			pidFileFOS = new FileOutputStream(pidFile);
			pidFileFOS.write(CurrentProcessInfo.getPIDStr().getBytes());
			pidFileFOS.write('\n');
			pidFileFOS.flush();
			
			
			// end single instance logic
			
			
			ScreenCenter screenCenter = new ScreenCenter();
			ServerCenter serverCenter = new ServerCenter(VNCServerConfig.serverPort, VNCServerConfig.listenBacklog, VNCServerConfig.serverBindAddress, screenCenter);
			screenCenter.setServerCenter(serverCenter);
			screenCenter.start();
			serverCenter.start();
			System.out.println("VNCServer is running!");
			serverCenter.join();
		}
		finally {
			if (pidFileFOS != null)     {pidFileFOS.close();}
			if (pidFileLock != null)    {pidFileLock.release();}
			if (pidFileRAF != null)     {pidFileRAF.close();}
			if (serverFileLock != null) {serverFileLock.release();}
			if (serverFileRAF != null)  {serverFileRAF.close();}
		}
	}
}