package com.jcope.vnc.event;

import java.awt.Point;
import java.io.Serializable;

public class VNCMouseInputEvent extends VNCInputEvent implements Serializable {

	private static final long serialVersionUID = -8488319490370968976L;
	public Point point;
	public int mouseKey;
	public Boolean isDown = null;
	
	public VNCMouseInputEvent(int flags, long when, Point point, int mouseKey) {
		super(flags, when);
		this.point = point;
		this.mouseKey = mouseKey;
	}
	
}