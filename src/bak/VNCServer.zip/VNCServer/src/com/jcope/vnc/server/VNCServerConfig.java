package com.jcope.vnc.server;

import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



public class VNCServerConfig {
	private static final boolean noPassword = true;
	
	public static final long authTimeout = 60000;
	public static final int serverPort = 4444;
	public static final long defaultRefreshMS = 1000;
	public static final long defaultMouseUpdateInterval = 300;
	public static final String serverBindAddress = null;
	public static final int listenBacklog = 0;
	public static final byte[] defaultPasswordHash;
	
	static {
		if (noPassword) {
			defaultPasswordHash = null;
		}
		else {
			final String defaultPassword = "vnc admin";
			try {
				defaultPasswordHash = cryptoHash(defaultPassword.getBytes());
			} catch (DigestException e) {
				e.printStackTrace();
				throw new ExceptionInInitializerError(e);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
				throw new ExceptionInInitializerError(e);
			}
		}
	}
	
	public static byte[] cryptoHash(byte[] src) throws DigestException, NoSuchAlgorithmException {
		MessageDigest hashFunc = MessageDigest.getInstance("SHA-256");
		byte[] rval = hashFunc.digest(src);
		// clear out the src byte array
		for (int idx = 0; idx < src.length; idx++) {
			src[idx] = 0;
		}
		// toggle the last 7 bits just for the hell of it
		for (int idx = 0; idx < rval.length; idx++) {
			rval[idx] ^= 127;
		}
		return rval;
	}
	
}