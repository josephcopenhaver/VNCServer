package com.jcope.vnc.event;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;
import java.io.Serializable;



public class VNCInputEvent implements Serializable {
	
	private static final long serialVersionUID = -5158506262738666991L;
	public int flags;
	public long when;
	
	public VNCInputEvent(int flags, long when) {
		this.flags = flags;
		this.when = when;
	}

	public static VNCInputEvent getInstance(InputEvent e) {
		if (e instanceof MouseEvent) {
			MouseEvent me = (MouseEvent) e;
			return new VNCMouseInputEvent(e.getModifiers(), e.getWhen(), me.getPoint(), me.getButton());
		}
		else if (e instanceof KeyEvent) {
			KeyEvent ke = (KeyEvent) e;
			return new VNCKeyInputEvent(e.getModifiers(), e.getWhen(), ke.getKeyChar(), ke.getKeyCode());
		}
		return null;
	}
	
	public static VNCKeyInputEvent getKeyEventInstance(KeyEvent e, boolean isDown) {
		VNCKeyInputEvent rval = new VNCKeyInputEvent(e.getModifiers(), e.getWhen(), e.getKeyChar(), e.getKeyCode());
		rval.isDown = isDown;
		return rval;
	}
	
	public static VNCMouseInputEvent getMouseClickEventInstance(MouseEvent e, boolean isDown) {
		VNCMouseInputEvent rval = new VNCMouseInputEvent(e.getModifiers(), e.getWhen(), e.getPoint(), e.getButton());
		rval.isDown = isDown;
		return rval;
	}
	
}