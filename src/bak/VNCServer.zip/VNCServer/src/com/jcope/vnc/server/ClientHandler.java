package com.jcope.vnc.server;

import java.awt.AWTException;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.Semaphore;

import com.jcope.remote.CommandCenter;
import com.jcope.remote.RemoteCall;
import com.jcope.remote.RemoteCallCenter;
import com.jcope.ui.JpegImage;
import com.jcope.util.MouseObserver;
import com.jcope.util.ObjectDisposedException;
import com.jcope.util.TaskDispatcher;
import com.jcope.vnc.RemoteInterface;
import com.jcope.vnc.RemoteVNCCall;
import com.jcope.vnc.event.VNCInputEvent;
import com.jcope.vnc.event.VNCKeyInputEvent;
import com.jcope.vnc.event.VNCMouseInputEvent;



public class ClientHandler extends Thread {
	
	private final int maxImagesToBuffer = 3;
	private final int maxMouseMovesToBuffer = 3;
	
	private RemoteCallCenter remoteCallCenter = new RemoteCallCenter();
	
	private Semaphore[] outboundImageQueueLock = {null};
	private Semaphore[] outboundMouseQueueLock = {null};
	private int numImageDeltasBuffered = 0;
	private int numMouseMoveDeltasBuffered = 0;
	private RemoteInterface remoteInterface = null;
	private ScreenCenter screenCenter;
	private ServerCenter serverCenter; //TODO: on I/O failure, close all streams and remove the client from the serverCenter
	private Socket socket;
	private Semaphore sendSema = new Semaphore(0, true);
	private ScreenManager currentScreen = null;
	private ObjectInputStream objectInputStream = null;
	private ObjectOutputStream objectOutputStream = null;
	private volatile boolean isAlive = true;
	private long refreshMS = VNCServerConfig.defaultRefreshMS;
	private volatile long lastImageFlushTime = 0;
	private volatile long lastMouseFlushTime = 0;
	private TaskDispatcher<Integer> mouseDispatcher = new TaskDispatcher<Integer>();
	private TaskDispatcher<Integer> imageDispatcher = new TaskDispatcher<Integer>();
	private TaskDispatcher<CommandCenter.NOTIFY_COMMAND> notificationDispatcher = new TaskDispatcher<CommandCenter.NOTIFY_COMMAND>();
	
	public ClientHandler(ServerCenter serverCenter, ScreenCenter screenCenter, Socket socket) throws IOException, AWTException {
		this.serverCenter = serverCenter;
		this.socket = socket;
		this.screenCenter = screenCenter;
		objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
		//System.out.println("Streams initialized!");
		//objectOutputStream.writeObject(null);
		objectInputStream = new ObjectInputStream(socket.getInputStream());
		//System.out.println("Streams initialized!");
	}
	
	public void deferImageFlush() {
		deferImageFlush(null);
	}
	
	public void deferImageFlush(final Long _now) {
		imageDispatcher.registerCallback(-2, new Runnable() {
			public void run() {
				long nextExpectedFlushTime = lastImageFlushTime + refreshMS;
				long now = (_now == null) ? System.currentTimeMillis() : _now; 
				if (nextExpectedFlushTime > now) {
					// flush is not overdue
					try {
						Thread.sleep(nextExpectedFlushTime-now);
						lastImageFlushTime = nextExpectedFlushTime;
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						System.err.println("Failed to buffer image parts for sending");
						e.printStackTrace();
					}
				}
				else {
					// flush is overdue
					lastImageFlushTime = now;
				}
			}
		});
	}
	
	public void deferMouseFlush() {
		deferMouseFlush(null);
	}
	
	public void deferMouseFlush(final Long _now) {
		mouseDispatcher.registerCallback(0, new Runnable() {
			public void run() {
				long nextExpectedFlushTime = lastMouseFlushTime + refreshMS;
				long now = (_now == null) ? System.currentTimeMillis() : _now; 
				if (nextExpectedFlushTime > now) {
					// flush is not overdue
					try {
						//System.out.println(String.format("%d, %d, %d", now, nextExpectedFlushTime, now-nextExpectedFlushTime));
						Thread.sleep(nextExpectedFlushTime - now);
						lastMouseFlushTime = nextExpectedFlushTime;
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						System.err.println("Failed to buffer image parts for sending");
						e.printStackTrace();
					}
				}
				else {
					// flush is overdue
					lastMouseFlushTime = now;
				}
			}
		});
	}
	
	public void ensureOutboundImageBufferCapacity() {
		if (numImageDeltasBuffered == maxImagesToBuffer) {
			return;
		}
		numImageDeltasBuffered++;
		if (numImageDeltasBuffered == maxImagesToBuffer) {
			synchronized(outboundImageQueueLock) {
				if (outboundImageQueueLock[0] == null) {
					final Semaphore newSema = new Semaphore(0, true);
					outboundImageQueueLock[0] = newSema;
					imageDispatcher.registerCallback(-3, new Runnable(){
						public void run() {
							synchronized(outboundImageQueueLock) {
								if (outboundImageQueueLock[0] == newSema) {
									try {
										outboundImageQueueLock[0].acquire();
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										System.err.println("Failed to throttle back image forwarding");
										e.printStackTrace();
									}
								}
							}
						}
					});
				}
			} 
		}
		try {
			sendSema.acquire();
			if (!isAlive) {
				return;
			}
			
			
			RemoteVNCCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.CONFIRM, new Runnable(){
				public void run() {
					synchronized(outboundImageQueueLock) {
						numImageDeltasBuffered--;
						if (outboundImageQueueLock[0] != null) {
							outboundImageQueueLock[0].release();
							outboundImageQueueLock[0] = null;
						}
					}
				}
			}, null, true /* interpret this as redrawMouse(asynch=true) */);
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} finally {
			sendSema.release();
		}
	}
	
	public void ensureOutboundMouseBufferCapacity() {
		if (numMouseMoveDeltasBuffered == maxMouseMovesToBuffer) {
			return;
		}
		numMouseMoveDeltasBuffered++;
		if (numMouseMoveDeltasBuffered == maxMouseMovesToBuffer) {
			synchronized(outboundMouseQueueLock) {
				if (outboundMouseQueueLock[0] == null) {
					final Semaphore newSema = new Semaphore(0, true);
					outboundMouseQueueLock[0] = newSema;
					mouseDispatcher.registerCallback(2, new Runnable(){
						public void run() {
							synchronized(outboundMouseQueueLock) {
								if (outboundMouseQueueLock[0] == newSema) {
									try {
										outboundMouseQueueLock[0].acquire();
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										System.err.println("Failed to throttle back image forwarding");
										e.printStackTrace();
									}
								}
							}
						}
					});
				}
			} 
		}
		try {
			sendSema.acquire();
			if (!isAlive) {
				return;
			}
			
			
			RemoteVNCCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.CONFIRM, new Runnable(){
				public void run() {
					synchronized(outboundMouseQueueLock) {
						numMouseMoveDeltasBuffered--;
						if (outboundMouseQueueLock[0] != null) {
							outboundMouseQueueLock[0].release();
							outboundMouseQueueLock[0] = null;
						}
					}
				}
			}, null);
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} finally {
			sendSema.release();
		}
	}
	
	public void run() {
		try {
			/**
			 * Authorization section
			 */
			final boolean authorized[] = {(VNCServerConfig.defaultPasswordHash == null)};
			if (authorized[0]) {
				objectOutputStream.writeObject(new RemoteVNCCall(CommandCenter.NOTIFY_COMMAND.AUTHORIZED));
			} else {
				objectOutputStream.writeObject(new RemoteVNCCall(CommandCenter.NOTIFY_COMMAND.UNAUTHORIZED));
			}
			objectOutputStream.flush();
			objectOutputStream.reset();
			if (!authorized[0]) {
				// launch thread that waits for auth token, all other tokens are responded with an UNAUTHORIZED token
				// if the auth token fails, then kill the client
				
				Thread authThread = new Thread() {
					public void run() {
						try {
							while (!authorized[0]) {
								Object obj = objectInputStream.readObject();
								//System.out.println("got obj");
								if (obj instanceof RemoteCall) {
									RemoteCall remoteCall = (RemoteCall) obj;
									//System.out.println("got rc obj");
									if (remoteCall.msgType == RemoteCallCenter.MSG_TYPE.REQUEST.getCode()) {
										//System.out.println("got rqst obj");
										if (remoteCall.commandType == CommandCenter.REQUEST_COMMAND.AUTHORIZATION.getCode()) {
											//System.out.println("got auth rqst");
											if (remoteCall.payload != null && remoteCall.payload instanceof byte[]) {
												synchronized(authorized) {
													//System.out.println(new String(VNCServerConfig.defaultPasswordHash));
													//System.out.println(new String((byte[]) remoteCall.payload));
													if (Arrays.equals(VNCServerConfig.defaultPasswordHash, (byte[]) remoteCall.payload)) {
														authorized[0] = true;
														objectOutputStream.writeObject(new RemoteVNCCall(remoteCall.msgID, true));
													}
													else {
														objectOutputStream.writeObject(new RemoteVNCCall(remoteCall.msgID, false));
													}
													objectOutputStream.flush();
													objectOutputStream.reset();
												}
												/*
												if (authorized[0]) {
													System.out.println("correct password");
												}
												else {
													System.out.println("Invalid password!");
												}
												*/
											}
											break;
										}
									}
									objectOutputStream.writeObject(new RemoteVNCCall(remoteCall.msgID, null));
									objectOutputStream.flush();
									objectOutputStream.reset();
								}
								objectOutputStream.writeObject(new RemoteVNCCall(CommandCenter.NOTIFY_COMMAND.UNAUTHORIZED, null));
								objectOutputStream.flush();
								objectOutputStream.reset();
							}
						} catch (ClassNotFoundException e) {
							e.printStackTrace();
							return;
						} catch (IOException e) {
							e.printStackTrace();
							return;
						}
					}
				};
				authThread.start();
				
				
				authThread.join(VNCServerConfig.authTimeout);
				synchronized(authorized) {
					if (!authorized[0]) {
						authThread.interrupt();
						System.out.println("Unathorized");
						objectOutputStream.writeObject(new RemoteVNCCall(CommandCenter.NOTIFY_COMMAND.ACCESS_DENIED, null));
						objectOutputStream.flush();
						objectOutputStream.reset();
						Thread.sleep(5000);
						destroy();
					}
				}
			}
			notificationDispatcher.start();
			MouseObserver.getInstance().unpause();
			sendSema.release();
			do {
				
				
				//TODO: read command java objects from socket
				// handle them each in turn
				//System.out.println("Waiting for Query...");
				// TODO: while !authorized, 
				Object obj = objectInputStream.readObject();
				//objectInputStream.reset(); // not needed, no memory leak issues here?
				//System.out.println("Got Query");
				if (obj == null) {
					destroy();
				}
				if (obj instanceof VNCInputEvent) {
					if (obj instanceof VNCKeyInputEvent) {
						VNCKeyInputEvent vnce = (VNCKeyInputEvent) obj;
						//System.out.println("VNCKeyInputEvent");
						remoteInterface.handleKeyEvent(vnce);
					}
					else if (obj instanceof VNCMouseInputEvent) {
						VNCMouseInputEvent vnce = (VNCMouseInputEvent) obj;
						//System.out.println("VNCMouseInputEvent");
						remoteInterface.handleMouseEvent(vnce); // getting null errors here still, even after making it volatile
					}
					else {
						//VNCInputEvent vnce = (VNCInputEvent) obj;
						System.out.println("Generic VNCInputEvent ???");
					}
				}
				else if (obj instanceof RemoteCall) {
					RemoteCall remoteCall = (RemoteCall)obj;
					if (!remoteCallCenter.handleResponse(remoteCall)) {
						if (remoteCall.msgType == RemoteCallCenter.MSG_TYPE.REQUEST.getCode()) {
							if (CommandCenter.REQUEST_COMMAND.isInstance(remoteCall.commandType)) {
								if (remoteCall.commandType == CommandCenter.REQUEST_COMMAND.GET_NUM_SCREENS.getCode()) {
									reply(remoteCall, getNumScreens());
								}
								else if (remoteCall.commandType == CommandCenter.REQUEST_COMMAND.SELECT_SCREEN.getCode()) {
									try {
										Object[] args = (Object[])remoteCall.payload;
										BufferedImage screenImg;
										reply(remoteCall, new Object[] {selectScreen((Integer)args[0], (Long)args[1]), currentScreen.getMetaData(), ((screenImg = currentScreen.getScreenshot())) == null ? null : new JpegImage(screenImg)});
										imageDispatcher.start();
										mouseDispatcher.start();
									}
									catch (Exception e2) {
										e2.printStackTrace();
										reply(remoteCall, false);
									}
								}
								else if (remoteCall.commandType == CommandCenter.REQUEST_COMMAND.GET_SCREEN.getCode()) {
									reply(remoteCall, getScreenImage());
								}
							}
						}
					}
				}
				
			} while (isAlive);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			destroy();
		}
	}
	
	public void setScreenManager(ScreenManager screenManager) {
		if (currentScreen != screenManager) {
			if (currentScreen != null) {
				try {
					currentScreen.removeClient(this);
				} catch (ObjectDisposedException e) {
					e.printStackTrace();
				}
			}
			currentScreen = screenManager;
			remoteInterface = RemoteInterface.getInstance(currentScreen);
		}
	}

	public void sendFullJpegImage(final BufferedImage image) {
		Runnable callback = new Runnable() {
			public void run() {
				try {
					sendSema.acquire();
					if (!isAlive) {
						return;
					}
					
					
					objectOutputStream.writeObject(new JpegImage(image));//Toolkit.getDefaultToolkit().createImage(image.getSource())
					objectOutputStream.flush(); // make sure object makes it into stream
					objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
					
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} finally {
					sendSema.release();
				}
			}
		};
		
		imageDispatcher.registerCallback(-1, callback);
	}
	
	int[] tmpTileInfo = new int[7];
	public void sendJpegImageDeltas(final ScreenManager screenManager, HashMap<Integer, int[]> newSlices) {
		//System.out.println("Forwarding slices");
		for (Entry<Integer, int[]> entry : newSlices.entrySet()) {
			final int id = entry.getKey();
			//System.out.println("Forwarding slice " + id);
			final int[] tile = entry.getValue();
			
			Runnable callback = new Runnable() {
				public void run() {
					BufferedImage image = screenManager.getBufferedTile(id, tile, tmpTileInfo);
					if (image == null)
					{
						return;
					}
					try {
						sendSema.acquire();
						if (!isAlive) {
							return;
						}
						
						
						objectOutputStream.writeObject(new JpegImage(id, image));//Toolkit.getDefaultToolkit().createImage(image.getSource())
						objectOutputStream.flush(); // make sure object makes it into stream
						objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
						
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						destroy();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						destroy();
					} finally {
						sendSema.release();
					}
				}
			};
			
			//System.out.println("Sending image slice");
			imageDispatcher.registerCallback(id, callback);
		}
	}
	
	public void notifyMouseMove(final Point p) {
		Runnable callback = new Runnable() {
			public void run() {
				try {
					sendSema.acquire();
					if (!isAlive) {
						return;
					}
					
					
					objectOutputStream.writeObject(p);
					objectOutputStream.flush(); // make sure object makes it into stream
					objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
					
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} finally {
					sendSema.release();
				}
			}
		};
		deferMouseFlush();
		mouseDispatcher.registerCallback(1, callback);
		ensureOutboundMouseBufferCapacity();
	}
	
	public void notify(final CommandCenter.NOTIFY_COMMAND commandType, final Object payload) {
		Runnable callback = new Runnable() {
			public void run() {
				try {
					sendSema.acquire();
					if (!isAlive) {
						return;
					}
					
					
					objectOutputStream.writeObject(new RemoteVNCCall(commandType, payload));
					objectOutputStream.flush(); // make sure object makes it into stream
					objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
					
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					destroy();
				} finally {
					sendSema.release();
				}
			}
		};
		notificationDispatcher.registerCallback(commandType, callback);
	}
	
	public void notify(CommandCenter.NOTIFY_COMMAND commandType) {
		notify(commandType, null);
	}
	
	public void reply(RemoteCall query, Object response) {
		try {
			sendSema.acquire();
			if (!isAlive) {
				return;
			}
			
			objectOutputStream.writeObject(new RemoteVNCCall(query.msgID, response));
			objectOutputStream.flush(); // make sure object makes it into stream
			objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			destroy();
		} finally {
			sendSema.release();
		}
	}
	
	@SuppressWarnings("deprecation")
	public synchronized void destroy() {
		if (!isAlive) {
			return;
		}
		isAlive = false;
		//System.out.println("ClientHandler being destroyed!");
		imageDispatcher.dispose();
		notificationDispatcher.dispose();
		if (objectOutputStream != null) {
			try {
				ObjectOutputStream tmp = objectOutputStream;
				objectOutputStream = null;
				tmp.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (objectInputStream != null) {
			try {
				ObjectInputStream tmp = objectInputStream;
				objectInputStream = null;
				tmp.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (socket != null) {
			try {
				Socket tmp = socket;
				socket = null;
				tmp.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (serverCenter != null) {
			serverCenter.removeClient(this);
			serverCenter = null;
		}
		if (currentScreen != null) {
			try {
				currentScreen.removeClient(this);
			} catch (ObjectDisposedException e) {
				e.printStackTrace();
			}
			currentScreen = null;
		}
	}
	
	private boolean selectScreen(int idx) {
		return screenCenter.pairClientAndScreen(this, idx);
	}
	
	private boolean selectScreen(int idx, long refreshMS) {
		boolean rval = selectScreen(idx);
		if (rval) {
			currentScreen.minimizeRefreshMS(refreshMS);
			this.refreshMS = refreshMS;
		}
		return rval;
	}
	
	private int getNumScreens() {
		return screenCenter.getNumScreens();
	}
	
	private JpegImage getScreenImage() {
		BufferedImage rval = currentScreen.getScreenshot();
		if (rval == null) {
			return null;
		}
		else {
			try {
				return new JpegImage(rval);
			} catch(Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}
	
	public long getRefreshMS() {
		return refreshMS;
	}
	
}