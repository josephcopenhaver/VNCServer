package com.jcope.vnc.client;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.InvalidParameterException;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.jcope.remote.CommandCenter;
import com.jcope.remote.RemoteCall;
import com.jcope.remote.RemoteCallCenter;
import com.jcope.ui.JpegImage;
import com.jcope.util.TaskDispatcher;
import com.jcope.vnc.RemoteVNCCall;
import com.jcope.vnc.event.VNCInputEvent;
import com.jcope.vnc.event.VNCKeyInputEvent;
import com.jcope.vnc.event.VNCMouseInputEvent;
import com.jcope.vnc.server.VNCServerConfig;



class ImagePanel extends JPanel {
	
	private static final long serialVersionUID = -1500904868255038688L;
  	private Image img = null;
  	private boolean fitToComponent;
  	
  	public ImagePanel(boolean fitToComponent) {
  		this.fitToComponent = fitToComponent;
  	}
  	
  	public void setFitToComponent(boolean fitToComponent) {
  		this.fitToComponent = fitToComponent;
  	}

  	public void setImage(Image img) {
  		this.img = img;
  		if (!fitToComponent) {
  			setSizeAbsolute(new Dimension(img.getWidth(null), img.getHeight(null)));
  		}
  		setLayout(null);
  	}
  	
  	public void setSizeAbsolute(Dimension size) {
  		/*
  		System.out.println(String.format("\nImage panel size set to (%d, %d)", size.width, size.height));
  		for (StackTraceElement e : Thread.currentThread().getStackTrace()) {
  			System.out.println(e);
  		}
  		System.out.println();
		*/
  		super.setSize(size);
  		setPreferredSize(size);
  		setMinimumSize(size);
  		setMaximumSize(size);
  	}
  	
  	public void paintComponent(Graphics g) {
  		if (img != null) {
  			if (fitToComponent) {
  				Rectangle visibleRect = this.getVisibleRect();
  				g.drawImage(img, 0, 0, visibleRect.width, visibleRect.height, null);
  			}
  			else {
  				g.drawImage(img, 0, 0, null);
  			}
	  	}
  	}
  	
  	public Image getImage() {
  		return img;
  	}

}


public class VNCViewer implements Runnable {
	
	private static final boolean debug = false;
	
	private static final Object[] yesNoOptions = {"Yes", "No"};
	
	private JFrame frame = new JFrame();
	private ImagePanel imagePanel;
	private RemoteCallCenter remoteCallCenter = new RemoteCallCenter();
	private Dimension screenSize = null;
	private Dimension aspectRatio = null;
	private Point lastMouseLocation = null;
	private Point mouseLocation = null;
	private JpegImage screen = null;
	private TaskDispatcher<Object> inputHandlingDispatcher;
	private TaskDispatcher<Object> outputHandlingDispatcher;
	private volatile boolean isAlive = false;
	private ObjectOutputStream objectOutputStream = null;
	
	private LinkedList<VNCInputEvent> outboundEventQueue = new LinkedList<VNCInputEvent>();
	private VNCInputEvent lastMouseMoveEvent[] = {null};
	private VNCInputEvent lastMouseWheelEvent[] = {null};
	private VNCInputEvent lastKeyEvent[] = {null};
	private JScrollPane scrollPane;
	private JMenuBar mainMenuBar;
	private Runnable runAspectSyncLater[] = {null};
	private boolean ignoreNextResizeEvent = false;
	
	private int numHorizontalTiles = 0;
	private int mNumHorizontalTiles = 0;
	private int numVerticalTiles = 0;
	private Dimension sliceSize = null;
	
	// TODO: work out scaling factors after the fact in resize events.
	// may need to stop image updating while resizing
	private double xScale = 1;
	private double yScale = 1;
	private volatile boolean canForwardEvents = false;
	private volatile boolean preserveAspectRatio = false;
	private volatile boolean fitToFrame = false;
	
	public VNCViewer() {
		imagePanel = new ImagePanel(fitToFrame);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		imagePanel.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent e) {
				return;
			}
			public void mouseEntered(MouseEvent e) {
				return;
			}
			public void mouseExited(MouseEvent e) {
				return;
			}
			public void mouseReleased(MouseEvent e) {
				if (canForwardEvents) {
					sendMouseClickEvent(e, false);
				}
			}
			public void mousePressed(MouseEvent e) {
				if (canForwardEvents) {
					sendMouseClickEvent(e, true);
				}
			}
		});
		imagePanel.addMouseMotionListener(new MouseMotionListener() {
			public void mouseMoved(MouseEvent e) {
				if (canForwardEvents) {
					sendMouseMoveEvent(e);
				}
			}
			public void mouseDragged(MouseEvent e) {
				if (canForwardEvents) {
					sendMouseMoveEvent(e);
				}
			}
		});
		frame.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				if (canForwardEvents) {
					//TODO: finish
				}
				return;
			}
		});
		frame.addKeyListener(new KeyListener() {
			public void keyTyped(KeyEvent e) {
				return;
			}
			public void keyPressed(KeyEvent e) {
				if (canForwardEvents) {
					sendKeyEvent(e, true);
				}
			}
			public void keyReleased(KeyEvent e) {
				if (canForwardEvents) {
					sendKeyEvent(e, false);
				}
			}
		});
		mainMenuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit");
		JMenu sendMenu = new JMenu("Send");
		final JCheckBoxMenuItem fitToFrameMenu = new JCheckBoxMenuItem("Fit to Frame");
		fitToFrameMenu.setState(fitToFrame);
		fitToFrameMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fitToFrameMenu.setState(fitToFrame = !fitToFrame);
				syncFitToFrameSetting();
			}
		});
		
		final JCheckBoxMenuItem preserveAspectRatioMenu = new JCheckBoxMenuItem("Preserve Aspect Ratio");
		preserveAspectRatioMenu.setState(preserveAspectRatio);
		preserveAspectRatioMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				preserveAspectRatioMenu.setState(preserveAspectRatio = !preserveAspectRatio);
				syncPreserveAspectRatioSetting();
			}
		});
		
		JMenuItem ctrlAltDeleteMenuItem = new JMenuItem("Ctrl Alt Delete");
		ctrlAltDeleteMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long now = System.currentTimeMillis();
				synchronized(lastKeyEvent) {
					synchronized(outboundEventQueue) {
						VNCKeyInputEvent ke = new VNCKeyInputEvent(0, now, '\0', KeyEvent.VK_CONTROL);
						ke.isDown = true;
						outboundEventQueue.add(ke);
						ke = new VNCKeyInputEvent(0, ++now, '\0', KeyEvent.VK_ALT);
						ke.isDown = true;
						outboundEventQueue.add(ke);
						ke = new VNCKeyInputEvent(0, ++now, '\0', KeyEvent.VK_DELETE);
						ke.isDown = true;
						outboundEventQueue.add(ke);
						ke = new VNCKeyInputEvent(0, ++now, '\0', KeyEvent.VK_DELETE);
						ke.isDown = false;
						outboundEventQueue.add(ke);
						ke = new VNCKeyInputEvent(0, ++now, '\0', KeyEvent.VK_ALT);
						ke.isDown = false;
						outboundEventQueue.add(ke);
						ke = new VNCKeyInputEvent(0, ++now, '\0', KeyEvent.VK_CONTROL);
						ke.isDown = false;
						outboundEventQueue.add(ke);
						lastKeyEvent[0] = ke;
					}
				}
			}
		});
		
		sendMenu.add(ctrlAltDeleteMenuItem);
		editMenu.add(fitToFrameMenu);
		editMenu.add(preserveAspectRatioMenu);
		mainMenuBar.add(editMenu);
		mainMenuBar.add(sendMenu);
		frame.setJMenuBar(mainMenuBar);
		//frame.setContentPane(imagePanel);
		scrollPane = new JScrollPane(imagePanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		// TODO: find out if this should go on the scrollPane or the imagePanel
		frame.addComponentListener(new ComponentListener() {  
	        public void componentResized(ComponentEvent e) {
	        	updateScale(null);
	        	if (ignoreNextResizeEvent) {
	        		ignoreNextResizeEvent = false;
	        		return;
	        	}
	        	synchronized(runAspectSyncLater) {
		        	if (runAspectSyncLater[0] == null) {
		        		runAspectSyncLater[0] = new Runnable() {
			        		public void run() {
			        			synchronized(runAspectSyncLater) {
			        				runAspectSyncLater[0] = null;
			        			}
			        			syncPreserveAspectRatioSetting();
			        		}
			        	};
			        	EventQueue.invokeLater(runAspectSyncLater[0]);
		        	}
	        	}
	        }
	        public void componentHidden(ComponentEvent e) {
	        	// nada
	        }
	        public void componentShown(ComponentEvent e) {
	        	// nada
	        }
	        public void componentMoved(ComponentEvent e) {
	        	// nada
	        }
		});

		frame.setContentPane(scrollPane);
		frame.setVisible(true);
		frame.setSize(500, 500);
		syncFitToFrameSetting();
		syncPreserveAspectRatioSetting();
	}
	
	public static void main(String[] args) throws InterruptedException {
		new VNCViewer().run();
	}
	
	private void handleNewScreenSize(int[] args) {
		Dimension size = new Dimension(args[0], args[1]);
		if (!size.equals(screenSize)) {
			screenSize = size;
			aspectRatio = getAspectRatio(size);
			System.out.println(String.format("Set: Aspect ratio is %d, %d from %d, %d", aspectRatio.width, aspectRatio.height, screenSize.width, screenSize.height));
			syncPreserveAspectRatioSetting();
		}
		sliceSize = new Dimension(args[2], args[3]);
		numHorizontalTiles = (int) Math.ceil(((double)args[0])/sliceSize.getWidth());
		numVerticalTiles = (int) Math.ceil(((double)args[1])/sliceSize.getHeight());
		mNumHorizontalTiles = numHorizontalTiles - 1;
		System.out.println(String.format("TileDimensions(%d, %d)", numHorizontalTiles, numVerticalTiles));
	}
	
	private Dimension getRealImagePanelSize() {
		Dimension currentImagePanelSize = imagePanel.getVisibleRect().getSize();
		currentImagePanelSize.setSize(currentImagePanelSize.width, currentImagePanelSize.height - mainMenuBar.getHeight());
		currentImagePanelSize.setSize(currentImagePanelSize.width < 0 ? 0 : currentImagePanelSize.width, currentImagePanelSize.height < 0 ? 0 : currentImagePanelSize.height);
		return currentImagePanelSize;
	}
	
	private void syncPreserveAspectRatioSetting() {
		if (preserveAspectRatio && aspectRatio != null) {
			Dimension currentImagePanelSize = getRealImagePanelSize();
			Dimension currentAspectRatio = getAspectRatio(currentImagePanelSize.width < 1 ? 1 : currentImagePanelSize.width, currentImagePanelSize.height < 1 ? 1 : currentImagePanelSize.height);
			if (!currentAspectRatio.equals(aspectRatio)) {
				Dimension size;
				Dimension offsetSize = frame.getSize();
				offsetSize.setSize(offsetSize.width - currentImagePanelSize.width, offsetSize.height - currentImagePanelSize.height);
				if ((((double)currentAspectRatio.width)/((double)currentAspectRatio.height)) > (((double)aspectRatio.width)/((double)aspectRatio.height))) {
					size = new Dimension(currentImagePanelSize.height * aspectRatio.width / aspectRatio.height, currentImagePanelSize.height);
				}
				else {
					size = new Dimension(currentImagePanelSize.width, currentImagePanelSize.width * aspectRatio.height / aspectRatio.width);
				}
				if (!(currentImagePanelSize.equals(size))) { //  || Math.sqrt((double)((Math.pow(currentImagePanelSize.width - size.width, 2) + Math.pow(currentImagePanelSize.height - size.height, 2)))) < 2
					imagePanel.setSizeAbsolute(size);
					updateScale(size);
					System.out.println(String.format("aspectSync: new scale %f,\t%f", xScale, yScale));
					size.setSize(size.width + offsetSize.width, size.height + offsetSize.height);
					if (!frame.getSize().equals(size)) {
						frame.setSize(size);
						ignoreNextResizeEvent = true;
					}
				}
			}
		}
	}
	
	private void updateScale(Dimension size) {
		if (!fitToFrame || screenSize == null) {
			xScale = 1;
			yScale = 1;
			return;
		}
		if (size == null) {
			size = getRealImagePanelSize();
		}
		xScale = ((double)size.width)/((double)screenSize.width);
		yScale = ((double)size.height)/((double)screenSize.height);
	}
	
	private void syncFitToFrameSetting() {
		imagePanel.setFitToComponent(fitToFrame);
		if (fitToFrame) {
			//Dimension imagePanelSize = getRealImagePanelSize();
			//xScale = screenSize == null ? 1 : ((double)imagePanelSize.width)/((double)screenSize.width);
			//yScale = screenSize == null ? 1 : ((double)imagePanelSize.height)/((double)screenSize.height);
			Rectangle visibleRect = imagePanel.getVisibleRect();
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			imagePanel.setSizeAbsolute(new Dimension(visibleRect.width, visibleRect.height));
		}
		else {
			//xScale = 1;
			//yScale = 1;
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			imagePanel.setSizeAbsolute(imagePanel.getSize());
		}
		updateScale(null);
		System.out.println(String.format("fitFrameSync: new scale %f,\t%f", xScale, yScale));
	}
	
	private Dimension getAspectRatio(Dimension screenSize) {
		int gcf = getGreatestCommonFactor(screenSize.width, screenSize.height);
		if (gcf == 1) {
			return screenSize;
		}
		else {
			return new Dimension(screenSize.width / gcf, screenSize.height / gcf);
		}
	}
	
	private Dimension getAspectRatio(int width, int height) {
		int gcf = getGreatestCommonFactor(width, height);
		if (gcf == 1) {
			return new Dimension(width, height);
		}
		else {
			return new Dimension(width / gcf, height / gcf);
		}
	}
	
	private int getGreatestCommonFactor(int a, int b) {
		//System.out.println(String.format("getGreatestCommonFactor(%d,%d)", a, b));
		if (a < 1 || b < 1) {
			throw new InvalidParameterException("Arguments must be greater than zero");
		}
		if (a > b) {
			a ^= b;
			b ^= a;
			a ^= b;
		}
		if (b % a == 0) {
			return a;
		}
		int rval = a / ((a % 2 == 0) ? 2 : 3);
		if (rval <= 1) {
			return 1;
		}
		while (rval > 1) {
			if (a % rval == 0 && b % rval == 0) {
				break;
			}
			rval--;
		}
		return rval;
	}
	
	public void run() {
		System.out.println("Running...\n");
		boolean wasConnected;
		final boolean[] ioExceptionThrown = {false};
		do {
			ioExceptionThrown[0] = false;
			isAlive = true;
			wasConnected = false;
			Socket socket = null;
			ObjectInputStream objectInputStream = null;
			inputHandlingDispatcher = new TaskDispatcher<Object>();
			inputHandlingDispatcher.setErrorHandler(new Runnable() {
				public void run() {
					isAlive = false;
					inputHandlingDispatcher.dispose();
				}
			});
			outputHandlingDispatcher = new TaskDispatcher<Object>();
			outputHandlingDispatcher.setErrorHandler(new Runnable() {
				public void run() {
					isAlive = false;
					outputHandlingDispatcher.dispose();
				}
			});
			inputHandlingDispatcher.start();
			outputHandlingDispatcher.start();
			//outputHandlingDispatcher.setDeferred(VNCMouseInputEvent.class);
			try {
				//TODO: prompt for network ip/fqdn
				//TODO: prompt for port
				//TODO: prompt for password?
				socket = new Socket(VNCViewerConfig.serverAddress, VNCViewerConfig.serverPort);
				wasConnected = true;
				System.out.println("Connection Established");
				objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
				System.out.println("Streams established");
				System.out.flush();
				
				objectInputStream = new ObjectInputStream(socket.getInputStream());
				
				System.out.println("Streams established");
				System.out.flush();
				//objectInputStream.readObject(); // flush out first null object
				
				final ObjectInputStream finalObjectInputStream = objectInputStream;
				
				//TODO: spawn thread to handle input from server
				Thread inputHandler = new Thread() {
					public void run() {
						Object obj = null;
						try {
							while (isAlive && (obj = finalObjectInputStream.readObject()) != null) {
								//System.out.println("Got input object: " + obj.getClass().getName());
								if (obj instanceof RemoteCall) {
									//System.out.println((RemoteCall)obj);
									RemoteCall remoteCall = (RemoteCall)obj;
									if (!remoteCallCenter.handleResponse(remoteCall)) {
										//TODO: attempt to handle it if it is a notify obj
										if (remoteCall.msgType == RemoteCallCenter.MSG_TYPE.REQUEST.getCode()) {
											if (CommandCenter.REQUEST_COMMAND.isInstance(remoteCall.commandType) && remoteCall.commandType == CommandCenter.REQUEST_COMMAND.CONFIRM.getCode()) {
												//Warning: confirming the request before handling the action
												confirmRequest(remoteCall);
												if (remoteCall.payload != null) {
													// TODO: verify that this allows for the mouse to be redrawn
													// the client can get a mouse update then a new frame
													// the new frame could clobber the mouse location
													redrawMouse(true);
												}
											}
										}
										else if (remoteCall.msgType == RemoteCallCenter.MSG_TYPE.NOTIFY.getCode()) {
											if (CommandCenter.NOTIFY_COMMAND.isInstance(remoteCall.commandType)) {
												if (remoteCall.commandType == CommandCenter.NOTIFY_COMMAND.MOUSE_MOVE.getCode()) {
													// TODO: handle mouse leaving the screen
													// this event means that the mouse is gone from the screen
													System.out.println("The mouse has moved away from the screen");
													if (remoteCall.payload != null) {
														new Exception("WTF, there is not supposed to be any payload for mouse moving away from the screen!");													
													}
													handleMouseMove(null);
												}
												else if (remoteCall.commandType == CommandCenter.NOTIFY_COMMAND.SCREEN_DIMENSIONS_CHANGED.getCode()) {
													// TODO: handle screen dimensions changing
													if (remoteCall.payload instanceof int[]) {
														handleNewScreenSize((int[]) remoteCall.payload);
													}
												}
												else if (remoteCall.commandType == CommandCenter.NOTIFY_COMMAND.NEW_SCREEN.getCode()) {
													// TODO: handle sync'ing the fact that there is another screen available
													System.out.println("New screen available on the server");
												}
											}
										}
									}
								}
								else if (obj instanceof Point) {
									handleMouseMove((Point)obj);
								}
								else if (obj instanceof JpegImage) {
									final JpegImage jpegImage = (JpegImage) obj;
									int imageID = jpegImage.getID();
									inputHandlingDispatcher.registerCallback(imageID == -1 ? CommandCenter.NOTIFY_COMMAND.NEW_SCREEN : imageID, new Runnable() {
										public void run() {
											handleJpegImage(jpegImage);
										}
									});
								}
								else {
									//TODO: die, protocol error, unknown communication object.
								}
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							ioExceptionThrown[0] = true;
							e.printStackTrace();
						} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} finally {
							isAlive = false;
						}
					}
				};
				
				// read the auth status notification
				System.out.println("Waiting on auth notification");
				Object obj = objectInputStream.readObject();
				System.out.println("Got auth handshake token...");
				boolean protocolOkay = false;
				boolean authorized = false;
				if (obj instanceof RemoteCall) {
					RemoteCall remoteCall = (RemoteCall) obj;
					if ((CommandCenter.NOTIFY_COMMAND.isInstance(remoteCall.commandType)) && remoteCall.msgType == RemoteCallCenter.MSG_TYPE.NOTIFY.getCode()) {
						if (remoteCall.commandType == CommandCenter.NOTIFY_COMMAND.UNAUTHORIZED.getCode()) {
							protocolOkay = true;
						}
						else if (remoteCall.commandType == CommandCenter.NOTIFY_COMMAND.AUTHORIZED.getCode()) {
							protocolOkay = true;
							authorized = true;
						}
					}
				}
				if (!protocolOkay) {
					throw new NullPointerException("Never got authorization notification!");
				}
				
				System.out.println("Starting input handler");
				inputHandler.start();
				
				//TODO: fetch number of screens
				final Semaphore sema = new Semaphore(0);
				final RemoteCall[] args = {null};
				synchronized(objectOutputStream) {
					if (!authorized) {
						System.out.println("must authorize connection");
						String msgStr = JOptionPane.showInputDialog(null, "Enter a password: ", "AUTHORIZATION", 1);
						if (msgStr != null && msgStr.length() > 0) {
							byte[] msg = VNCServerConfig.cryptoHash(msgStr.getBytes());
							msgStr = null;
							
							RemoteVNCCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.AUTHORIZATION, new Runnable(){
								public void run() {
									sema.release();
								}
							}, args, msg);
							if (!sema.tryAcquire(60, TimeUnit.SECONDS)) {
								throw new RuntimeException("Never received a response for how many screens are available");
							}
							if (args[0] == null || args[0].payload == null || !(args[0].payload instanceof Boolean) || !((Boolean)args[0].payload)) {
								throw new RuntimeException("Invalid password!");
							}
							args[0] = null;
						}
					}
					
					System.out.println("Waiting for screen enumeration");
					RemoteVNCCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.GET_NUM_SCREENS, new Runnable(){
						public void run() {
							sema.release();
						}
					}, args);
					if (!sema.tryAcquire(20, TimeUnit.SECONDS)) {
						throw new RuntimeException("Never received a response for how many screens are available");
					}
					
					if (args[0] == null || args[0].payload == null || !(args[0].payload instanceof Integer) || ((Integer)args[0].payload) <= 0) {
						throw new RuntimeException("Server has no screens that can be sampled");
					}
					System.out.println("Server has screens!");
					
					showScreenSelectionDialog(sema, args);
				}
				
				// Currently properly bound to a screen!
				
				canForwardEvents = true;
				
				
				/*
				//TODO: attempt to get current image for each screen?
				//TODO: prompt for screen selection
				Runnable refreshScreenCallback = new Runnable() {
					public void run() {
						//System.out.println("Got response");
						if (args[0] == null || args[0].payload == null || !(args[0].payload instanceof JpegImage)) {
							//System.out.println("Got NO image!");
							sema.release();
							return;
						}
						handleJpegImage((JpegImage)args[0].payload);
						try {
							Thread.sleep(VNCViewerConfig.refreshMS);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						sema.release();
					}
				};
				Thread.sleep(2000);
				while (isAlive) {
					//TODO: while connection active, check if local event reader has events to forward
					//Clear pull data placeholder//args[0] = null;
					//System.out.println("Sending new image request");
					//Pull data from server//RemoteCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.UPDATE_SCREEN, refreshScreenCallback, args);
					//TODO: make sure server is smart enough to ignore refresh commands if they are too frequent.
					sema.acquire();
				}
				*/
				inputHandler.join();
			
			} catch (IOException e) {
				ioExceptionThrown[0] = true;
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (objectOutputStream != null) {
					try {
						ObjectOutputStream tmp = objectOutputStream;
						objectOutputStream = null;
						tmp.close();
					} catch(Exception e) {
						e.printStackTrace();					
					}
				}
				if (objectInputStream != null) {
					try {
						ObjectInputStream tmp = objectInputStream;
						objectInputStream = null;
						tmp.close();
					} catch(Exception e) {
						e.printStackTrace();					
					}
				}
				if (socket != null) {
					try {
						Socket tmp = socket;
						socket = null;
						tmp.close();
					} catch(Exception e) {
						e.printStackTrace();					
					}
				}
			}
			inputHandlingDispatcher.dispose(); // make sure tasking is dead
			outputHandlingDispatcher.dispose();
			inputHandlingDispatcher = null;
			outputHandlingDispatcher = null;
			remoteCallCenter.reset(); // prevent memory leaks when connection is lost and reset msg counters
		} while (wasConnected && ioExceptionThrown[0] && JOptionPane.showOptionDialog(
					frame,
				    "Connection lost.\nRetry connecting to the server?",
				    "RECONNECT?",
				    JOptionPane.YES_NO_CANCEL_OPTION,
				    JOptionPane.QUESTION_MESSAGE,
				    null,
				    yesNoOptions,
				    yesNoOptions[0]
				) == 0 ||
				wasConnected && !ioExceptionThrown[0] && JOptionPane.showOptionDialog(
					frame,
				    "An unknown internal error or an unknown protocol error has occured",
				    "RECONNECT?",
				    JOptionPane.YES_NO_CANCEL_OPTION,
				    JOptionPane.QUESTION_MESSAGE,
				    null,
				    yesNoOptions,
				    yesNoOptions[0]
			   	) == 0 ||
			   	!wasConnected && JOptionPane.showOptionDialog(
			    	frame,
				    "Connection attempt failed.\nRetry connecting to the server?",
				    "RETRY CONNECTING?",
				    JOptionPane.YES_NO_CANCEL_OPTION,
				    JOptionPane.QUESTION_MESSAGE,
				    null,
				    yesNoOptions,
				    yesNoOptions[0]
			    ) == 0);
		System.out.println("Disposing frame");
		frame.dispose();
	}
	
	private void confirmRequest(RemoteCall query) {
		synchronized(objectOutputStream) {
			try {
				objectOutputStream.writeObject(new RemoteVNCCall(query.msgID, null));
				objectOutputStream.flush();
				objectOutputStream.reset();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	private void showScreenSelectionDialog(final Semaphore sema, final RemoteCall[] args) throws IOException, InterruptedException {
		// definitely have at least one screen
		args[0] = null;
		int selectedScreen = -1;
		// TODO: gather thumbnail / screen dimension meta data
		// TODO: show progress bar
		// TODO: offer screen detection dialog
		BufferedImage[] screenThumbnails = {};
		// JOptionPane.showInputDialog(frame, "Please select a screen", "Select a screen", JOptionPane.OK_CANCEL_OPTION, null /* icon */, screenThumbnails, null /* default selection */);
		
		selectedScreen = 0; // TODO: remove this over-ridding crap
		if (selectedScreen < 0) {
			throw new RuntimeException("No screen selected");
		}
		RemoteVNCCall.invoke(remoteCallCenter, objectOutputStream, CommandCenter.REQUEST_COMMAND.SELECT_SCREEN, new Runnable(){
			public void run() {
				sema.release();
			}
		}, args, new Object[]{selectedScreen, VNCViewerConfig.refreshMS});
		
		if (!sema.tryAcquire(20, TimeUnit.SECONDS)) {
			throw new RuntimeException("Never received confirmation of a default screen selection");
		}
		
		if (args[0] == null || args[0].payload == null || !(args[0].payload instanceof Object[]) || !(((Object[])args[0].payload)[0] instanceof Boolean) || ((Boolean)((Object[])args[0].payload)[0]) == false) {
			throw new RuntimeException("Failed to get confirmation of screen registry");
		}
		Object screenMetaDataObj = ((Object[])args[0].payload)[1];
		if (screenMetaDataObj != null && screenMetaDataObj instanceof int[]) {
			handleNewScreenSize((int[]) screenMetaDataObj);
		}
		Object screenImageObj = ((Object[])args[0].payload)[2];
		if (screenImageObj != null && screenImageObj instanceof JpegImage) {
			handleJpegImage((JpegImage) screenImageObj);
		}
	}
	
	private final Runnable sendEventQueueCallback = new Runnable() {
		public void run() {
			try {
				synchronized(lastMouseMoveEvent) {
				synchronized(lastKeyEvent) {
				synchronized(objectOutputStream) {
					synchronized(outboundEventQueue) {
						while (!outboundEventQueue.isEmpty()) {
							objectOutputStream.writeObject(outboundEventQueue.remove());
							objectOutputStream.reset();
						}
						objectOutputStream.flush();
					}
					lastMouseMoveEvent[0] = null;
					lastKeyEvent[0] = null;
				}
				}
				}
			}
			catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	};
	
	private void sendMouseClickEvent(MouseEvent e, boolean isDown) {
		VNCMouseInputEvent vnce = VNCInputEvent.getMouseClickEventInstance(e, isDown);
		synchronized(outboundEventQueue) {
			outboundEventQueue.add(vnce);
			if (outputHandlingDispatcher.getRegisteredCallback(VNCMouseInputEvent.class) == null) {
				outputHandlingDispatcher.registerCallback(VNCMouseInputEvent.class, sendEventQueueCallback);
			}
		}
	}
	
	private void sendMouseMoveEvent(MouseEvent e) {
		synchronized(lastMouseMoveEvent) {
			VNCMouseInputEvent vncme = (lastMouseMoveEvent[0] instanceof VNCMouseInputEvent) ? (VNCMouseInputEvent)lastMouseMoveEvent[0] : null;
			if (vncme != null && vncme.flags == e.getModifiers()) {
				Point point = e.getPoint();
				if (vncme.point.equals(point)) {
					return;
				}
				else {
					vncme.when = e.getWhen();
					vncme.point = point;
					return;
				}
			}
			VNCInputEvent vnce = VNCMouseInputEvent.getInstance(e);
			synchronized(outboundEventQueue) {
				outboundEventQueue.add(vnce);
				lastMouseMoveEvent[0] = vnce;
				if (outputHandlingDispatcher.getRegisteredCallback(VNCInputEvent.class) == null) {
					outputHandlingDispatcher.registerCallback(VNCInputEvent.class, sendEventQueueCallback);
				}
			}
		}
	}
	
	private void sendKeyEvent(KeyEvent e, boolean isDown) {
		// TODO: ignore repeats
		// track keys as they go down
		synchronized (lastKeyEvent) {
			VNCKeyInputEvent vncme = (lastKeyEvent[0] instanceof VNCKeyInputEvent) ? (VNCKeyInputEvent)lastKeyEvent[0] : null;
			if (vncme != null && vncme.flags == e.getModifiers() && vncme.charCode == e.getKeyChar() && vncme.keyCode == e.getKeyCode() && vncme.isDown == isDown) {
				vncme.repeats++;
				return;
			}
			VNCKeyInputEvent vnce = VNCInputEvent.getKeyEventInstance(e, isDown);
			synchronized(outboundEventQueue) {
				outboundEventQueue.add(vnce);
				lastKeyEvent[0] = vnce;
				if (outputHandlingDispatcher.getRegisteredCallback(VNCInputEvent.class) == null) {
					outputHandlingDispatcher.registerCallback(VNCInputEvent.class, sendEventQueueCallback);
				}
			}
		}
	}
	
	private JpegImage[] screenTiles = null;
	
	int debugSrcID = -1;
	
	private void handleJpegImage(JpegImage image) {
		synchronized(imagePanel) {
			//System.out.println("Got new image!");
			int idx = image.getID();
			if (idx == -1) {
				System.out.println(String.format("%d: Got new Full Image", ++debugSrcID));
				screen = image;
				try {
					image.reset();
					redrawMouse(false);
					debug_redrawTileGrid();
					imagePanel.setImage(image.getImage());
					//syncPreserveAspectRatioSetting();
					imagePanel.repaint(VNCViewerConfig.refreshMS);
					//imagePanel.paintImmediately(imagePanel.getBounds());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			else {
				System.out.println(String.format("Got new Image Tile %d", idx));
				int xTile = idx % numHorizontalTiles;
				int yTile = idx / numHorizontalTiles;
				int dstx = sliceSize.width;
				int dsty = sliceSize.height;
				/*
				int dstw, dsth;
				if (xScale != 1) {
					dstx *= xScale;
				}
				dstw  = dstx;
				*/
				dstx *= xTile;
				/*
				if (yScale != 1) {
					dsty *= yScale;
				}
				dsth = dsty;
				*/
				dsty *= yTile;
				//System.out.println(String.format("Drawing tile %d (%d, %d) at (%d, %d) which includes dilation (%f,%f)", idx, xTile, yTile, dstx, dsty, xScale, yScale));
				try {
					screen.reset();
					BufferedImage screenImage = screen.getImage();
					BufferedImage remoteImage = image.getImage();
					screenImage.getGraphics().drawImage(remoteImage, dstx, dsty, null);
					screen.mark();
					redrawMouse(false);
					debug_redrawTileGrid(idx);
					imagePanel.setImage(screen.getImage());
					/*
					if (xScale == 1 && yScale == 1) {
						imagePanel.repaint(VNCViewerConfig.refreshMS, dstx, dsty, remoteImage.getWidth(), remoteImage.getHeight());
					}
					else {
						imagePanel.repaint(VNCViewerConfig.refreshMS, (int)(((double)dstx) * xScale), (int)(((double)dsty) * yScale), ((int)(((double)remoteImage.getWidth()) * xScale)) + 2, ((int)(((double)remoteImage.getHeight()) * yScale)) + 2);
					}
					*/
					// imagePanel.repaint(VNCViewerConfig.refreshMS, dstx, dsty, dstw, dsth);
					imagePanel.repaint(VNCViewerConfig.refreshMS, dstx, dsty, remoteImage.getWidth(), remoteImage.getHeight());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return;
				}
			}
		}
	}
	
	private void debug_redrawTileGrid(Integer idx) throws IOException {
		if (!debug) {
			return;
		}
		Graphics g = screen.getImage().getGraphics();
		g.setColor(Color.ORANGE);
		for (int tidx = sliceSize.width; tidx < screenSize.width; tidx += sliceSize.width) {
			g.drawLine(tidx, 0, tidx, screenSize.height);
		}
		for (int tidx = sliceSize.height; tidx < screenSize.height; tidx += sliceSize.height) {
			g.drawLine(0, tidx, screenSize.width, tidx);
		}
		if (idx != null) {
			// highlight the tile that spawned the redraw proc
		}
	}
	
	private void debug_redrawTileGrid() throws IOException {
		debug_redrawTileGrid(null);
	}
	
	private void handleMouseMove(final Point newMouseLocation) {
		inputHandlingDispatcher.registerCallback(CommandCenter.NOTIFY_COMMAND.MOUSE_MOVE, new Runnable() {
			public void run() {
				lastMouseLocation = mouseLocation;
				mouseLocation = newMouseLocation;
				try {
					redrawMouse(true /* asynchronously from rest of image */);
				}
				catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		});
	}
	
	private static final int cursorImageSize = 5;
	private static final int mCursorImageSize = cursorImageSize + 1;
	private static final int cursorImageWidth = cursorImageSize * 2 + 3;
	private static final int cursorImageHeight = cursorImageSize * 2 + 2;
	
	private void redrawMouse(boolean asynch) throws IOException {
		synchronized(imagePanel) {
			if (screen == null) {
				return;
			}
			
			if (mouseLocation == null) {
				if (asynch && lastMouseLocation != null) {
					screen.reset();
					BufferedImage bufferedImage = screen.getImage();
					imagePanel.setImage(bufferedImage);
					//imagePanel.repaint(0, (int)(((double)(lastMouseLocation.x - mCursorImageSize)) * xScale), (int)(((double)(lastMouseLocation.y - mCursorImageSize)) * yScale), (int)(((double)(cursorImageWidth)) * xScale), (int)(((double)(cursorImageHeight)) * yScale));
					imagePanel.repaint(0, lastMouseLocation.x - mCursorImageSize, lastMouseLocation.y - mCursorImageSize, cursorImageWidth, cursorImageHeight);
					//imagePanel.repaint(0);
				}
			}
			else {
				
				
				Graphics g2;
				
				if (asynch) {
					screen.reset();
					BufferedImage bufferedImage = screen.getImage(); 
					imagePanel.setImage(bufferedImage);
					g2 = bufferedImage.createGraphics();
				}
				else {
					g2 = screen.getImage().createGraphics();				
				}
				
				
				int x = mouseLocation.x;
				int y = mouseLocation.y;
				int hx = x + cursorImageSize;
				int hy = y + cursorImageSize;
				x -= cursorImageSize;
				y -= cursorImageSize;
				
				
				// border frame critical points
				// for polygon filling
				int xp = x+2;
				int xm = x-1;
				int hxp = hx+2;
				int hxm = hx-1;
				int ym = y-1;
				int yp = y+1;
				int hyp = hy+1;
				int hym = hy-1;
				
				
				// draw border frame
				g2.setColor(Color.BLACK);
				// top left to bottom right
				g2.fillPolygon(new int[]{xp,xm,hxm,hxp}, new int[]{ym,yp,hyp,hym}, 4);
				// bottom left to top right
				g2.fillPolygon(new int[]{xm,xp,hxp,hxm}, new int[]{hym,hyp,yp,ym}, 4);
				
				
				// draw inner track lines
				g2.setColor(Color.WHITE);
				// top left to bottom right
				g2.drawLine(x, y, hx, hy);
				// bottom left to top right
				g2.drawLine(x, hy, hx, y);
				
				
				if (asynch) {
					if (lastMouseLocation != null && !lastMouseLocation.equals(mouseLocation)) {
						// repaint the previous cursor location without cursor
						//imagePanel.repaint(0, (int)(((double)(lastMouseLocation.x - mCursorImageSize)) * xScale), (int)(((double)(lastMouseLocation.y - mCursorImageSize)) * yScale), (int)(((double)(cursorImageWidth)) * xScale), (int)(((double)(cursorImageHeight)) * yScale));
						imagePanel.repaint(0, lastMouseLocation.x - mCursorImageSize, lastMouseLocation.y - mCursorImageSize, cursorImageWidth, cursorImageHeight);
					}
					// repaint the new cursor location
					//imagePanel.repaint(0, (int)(((double)(xm)) * xScale), (int)(((double)(ym)) * yScale), (int)(((double)(cursorImageWidth)) * xScale), (int)(((double)(cursorImageHeight)) * yScale));
					imagePanel.repaint(0, xm, ym, cursorImageWidth, cursorImageHeight);
					//imagePanel.repaint(0);
				}
			}
		}
	}
	
}