package com.jcope.vnc.server;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

import com.jcope.util.MouseObserver;



public class ServerCenter extends Thread {
	
	private int serverPort;
	private int listenBacklog;
	private InetAddress serverBindAddress;
	private ScreenCenter screenCenter;
	private ServerSocket serverSocket;
	private ReentrantLock fairLock = new ReentrantLock(true);
	public volatile ArrayList<ClientHandler> connectedClients = new ArrayList<ClientHandler>();
	
	public ServerCenter(int serverPort, int listenBacklog, String serverBindAddress, ScreenCenter screenCenter) throws UnknownHostException {
		if (serverBindAddress == null) {
			this.serverBindAddress = null;
		}
		else {
			this.serverBindAddress = InetAddress.getByName(serverBindAddress);
		}
		this.listenBacklog = listenBacklog;
		this.serverPort = serverPort;
		this.screenCenter = screenCenter;
	}
	
	public void run() {
		while (true) {
			try {
				if (serverBindAddress == null) {
					serverSocket = new ServerSocket(serverPort, listenBacklog);
				}
				else {
					serverSocket = new ServerSocket(serverPort, listenBacklog, serverBindAddress); 
				}
				System.out.println("Waiting for connections!");
				while (true) {
					Socket socket = serverSocket.accept();
					System.out.println("Got a new connection!");
					if (socket != null) {
						ClientHandler newClient = null;
						try {
							newClient = new ClientHandler(this, screenCenter, socket);
						}
						catch(Exception e2) {
							e2.printStackTrace();
							try {
								socket.close();
							}
							catch(Exception e3) {
								e3.printStackTrace();
							}
						}
						if (newClient != null) {
							lock();
							try {
								connectedClients.add(newClient);
							}
							finally {
								unlock();
							}
							newClient.start();
						}
					}
				}
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void removeClient(ClientHandler client) {
		lock();
		try {
			connectedClients.remove(client);
			if (connectedClients.size() == 0) {
				MouseObserver.getInstance().pause();
			}
		}
		finally {
			unlock();
		}
	}
	
	public void lock() {
		fairLock.lock();
	}
	
	public void unlock() {
		fairLock.unlock();
	}
}