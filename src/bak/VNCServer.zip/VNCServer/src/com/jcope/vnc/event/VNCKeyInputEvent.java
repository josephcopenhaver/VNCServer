package com.jcope.vnc.event;

import java.io.Serializable;

public class VNCKeyInputEvent extends VNCInputEvent implements Serializable {
	
	private static final long serialVersionUID = -2727824363024338662L;
	public char charCode;
	public int keyCode;
	public Boolean isDown = null;
	public int repeats = 0;
	
	public VNCKeyInputEvent(int flags, long when, char charCode, int keyCode) {
		super(flags, when);
		this.charCode = charCode;
		this.keyCode = keyCode;
	}
	
}