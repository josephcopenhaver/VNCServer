package com.jcope.vnc;

import java.awt.GraphicsDevice;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.jcope.util.MouseObserver;
import com.jcope.vnc.event.VNCInputEvent;
import com.jcope.vnc.event.VNCKeyInputEvent;
import com.jcope.vnc.event.VNCMouseInputEvent;
import com.jcope.vnc.server.ScreenManager;



public class RemoteInterface {
	
	//private static Toolkit toolkit = Toolkit.getDefaultToolkit();
	private static HashMap<ScreenManager, RemoteInterface> registeredScreenManagers = new HashMap<ScreenManager, RemoteInterface>();
	private static ReentrantLock fairRegisteredScreenManagersAccess = new ReentrantLock(true);
	
	private ReentrantLock fairRobotActionsLock = new ReentrantLock(true);
	
	//private static HashMap<Integer,Boolean> keyStateTracker = new HashMap<Integer,Boolean>();

	private Robot robot = null;
	private GraphicsDevice graphicsDevice = null;
	private static boolean enabled = false; // for loopback testing purposes only!
	
	private RemoteInterface(Robot robot, GraphicsDevice graphicsDevice) {
		this.robot = robot;
		this.graphicsDevice = graphicsDevice;
	}
	
	public static RemoteInterface getInstance(ScreenManager scm) {
		fairRegisteredScreenManagersAccess.lock();
		try {synchronized(registeredScreenManagers) {
			RemoteInterface rval = registeredScreenManagers.get(scm);
			if (rval == null) {
				rval = new RemoteInterface(scm.getRobot(), scm.getGraphicsDevice());
				registeredScreenManagers.put(scm, rval);
			}
			return rval;
		}}
		finally {
			fairRegisteredScreenManagersAccess.unlock();
		}
	}
	
	public static void unregister(ScreenManager scm) {
		fairRegisteredScreenManagersAccess.lock();
		try {synchronized(registeredScreenManagers) {
			registeredScreenManagers.remove(scm);
		}}
		finally {
			fairRegisteredScreenManagersAccess.unlock();
		}
	}
	
	public void mouseMove(int x, int y) {
		fairRobotActionsLock.lock();
		try {
			robot.mouseMove(x, y);
		}
		finally {
			fairRobotActionsLock.unlock();
		}
	}
	
	public void handleVNCInputEvent(VNCInputEvent e) {
		if (!enabled) {
			return;
		}
		if (e instanceof VNCMouseInputEvent) {
			VNCMouseInputEvent vncme = (VNCMouseInputEvent) e;
			handleMouseEvent(vncme);
		} else if (e instanceof VNCKeyInputEvent) {
			VNCKeyInputEvent vncme = (VNCKeyInputEvent) e;
			handleKeyEvent(vncme);
		}
		else {
			System.out.println("Unknown VNCInputEvent!");
		}
	}
	
	public void handleMouseEvent(VNCMouseInputEvent e) {
		fairRobotActionsLock.lock();
		try {
			if (!enabled) {
				return;
			}
			matchMouseFlags(e.flags);
			PointerInfo info = MouseObserver.getInstance().getPointerInfo();
			if (info == null || info.getDevice() != graphicsDevice || !e.point.equals(info.getLocation())) {
				mouseMove(e.point.x, e.point.y);
			}
			if (e.isDown != null) {
				if (e.isDown) {
					robot.mousePress(e.mouseKey);
				}
				else {
					robot.mouseRelease(e.mouseKey);
				}
			}
		}
		finally {
			fairRobotActionsLock.unlock();
		}
	}
	
	public void handleKeyEvent(VNCKeyInputEvent e) {
		fairRobotActionsLock.lock();
		try {
			matchKeyFlags(e.flags);
			//modifyKeyState(e.charCode, e.keyCode, e.isDown);
			//boolean isDown = toolkit.getLockingKeyState(e.keyCode);
			if (e.isDown == null) {
				System.out.println("WTF? some kind of meta keystate flag event without a key press/release?");
			}
			else {
				/*
				boolean isDown;
				synchronized(keyStateTracker) {
					isDown = isKeyDown(e.keyCode);
					if (e.isDown != isDown) {
						if (isDown) {
							robot.keyPress(e.keyCode);
							keyStateTracker.put(e.keyCode, true);
						}
						else {
							robot.keyRelease(e.keyCode);
							keyStateTracker.remove(e.keyCode);
						}
					}
					else if (isDown) {
						// the key is already down, but getting another down event...
						// send the key down event again to be 1 to 1
						robot.keyPress(e.keyCode);
					}
					else {
						// key up event and the key is already up, just send it again to be 1-1
						robot.keyRelease(e.keyCode);
					}
				}
				*/
				int repeats = e.repeats;
				if (e.isDown) {
					do {
						robot.keyPress(e.keyCode);
					} while (0 != repeats--);
				}
				else {
					do {
						robot.keyRelease(e.keyCode);
					} while (0 != repeats--);
				}
			}
		}
		finally {
			fairRobotActionsLock.unlock();
		}
	}
	
	/*
	public boolean isKeyDown(int keyCode) {
		synchronized(keyStateTracker) {
			Boolean isDown = keyStateTracker.get(keyCode);
			return (isDown != null && isDown);
		}
	}
	*/
	
	public void matchMouseFlags(int flags) {
		// TODO: complete
	}
	
	public void matchKeyFlags(int flags) {
		// TODO: complete
	}
	
}