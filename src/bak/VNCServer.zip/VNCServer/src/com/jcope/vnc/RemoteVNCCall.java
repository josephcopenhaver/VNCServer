package com.jcope.vnc;

import java.io.IOException;
import java.io.ObjectOutputStream;

import com.jcope.remote.Callback;
import com.jcope.remote.CommandCenter;
import com.jcope.remote.RemoteCall;
import com.jcope.remote.RemoteCallCenter;


public class RemoteVNCCall extends RemoteCall {
	
	private static final long serialVersionUID = -7512881365301308792L;
	
	public RemoteVNCCall(int replyID, Object payload) {
		msgID = replyID;
		msgType = RemoteCallCenter.MSG_TYPE.REPLY.getCode();
		commandType = 0;
		this.payload = payload;
	}

	public RemoteVNCCall(CommandCenter.NOTIFY_COMMAND commandType, Object payload) {
		msgID = RemoteCallCenter.getNextNotifyID();
		msgType = RemoteCallCenter.MSG_TYPE.NOTIFY.getCode();
		this.commandType = commandType.getCode();
		this.payload = payload;
	}

	public RemoteVNCCall(CommandCenter.NOTIFY_COMMAND commandType) {
		this(commandType, null);
	}

	public RemoteVNCCall(CommandCenter.REQUEST_COMMAND commandType, Runnable callback, Object payload) {
		msgID = RemoteCallCenter.getNextRequestID();
		msgType = RemoteCallCenter.MSG_TYPE.REQUEST.getCode();
		this.commandType = commandType.getCode();
		this.payload = payload;
	}

	public RemoteVNCCall(CommandCenter.REQUEST_COMMAND commandType, Runnable callback) {
		this(commandType, callback, null);
	}
	
	public String toString() {
		return String.format("RC%d - %s(%d):%s(%d) - payload?%c", msgID, RemoteCallCenter.getMessageTypeName(msgType), msgType, CommandCenter.getCommandTypeName(msgType, commandType), commandType, (payload == null ? 'N' : 'Y'));
	}

	public static int invoke(RemoteCallCenter remoteCallCenter, ObjectOutputStream objectOutputStream, CommandCenter.REQUEST_COMMAND commandType, Runnable callback, RemoteCall[] args, Object payload) throws IOException {
		RemoteVNCCall remoteVNCCall = new RemoteVNCCall(commandType, callback, payload);
		remoteCallCenter.callbackRegistry.put(remoteVNCCall.msgID, new Callback(callback, args));
		objectOutputStream.writeObject(remoteVNCCall);
		objectOutputStream.flush(); // make sure object makes it into stream
		objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
		return remoteVNCCall.msgID;
	}

	public static int invoke(RemoteCallCenter remoteCallCenter, ObjectOutputStream objectOutputStream, CommandCenter.REQUEST_COMMAND commandType, Runnable callback, RemoteCall[] args) throws IOException {
		return invoke(remoteCallCenter, objectOutputStream, commandType, callback, args, null);
	}

	public static int invoke(ObjectOutputStream objectOutputStream, CommandCenter.NOTIFY_COMMAND commandType, Object payload) throws IOException {
		RemoteVNCCall remoteVNCCall = new RemoteVNCCall(commandType, payload);
		objectOutputStream.writeObject(remoteVNCCall);
		objectOutputStream.flush(); // make sure object makes it into stream
		objectOutputStream.reset(); // remove objects from stream reference tracker, massive memory leak hole
		return remoteVNCCall.msgID;
	}
	public static int invoke(ObjectOutputStream objectOutputStream, CommandCenter.NOTIFY_COMMAND commandType) throws IOException {
		return invoke(objectOutputStream, commandType, null);
	}
}