package com.jcope.vnc.server;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.PointerInfo;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

import com.jcope.remote.CommandCenter;
import com.jcope.util.MouseMoveListener;
import com.jcope.util.MouseObserver;
import com.jcope.util.ObjectDisposedException;



public class ScreenCenter extends Thread {
	
	private volatile boolean disposed = false;
	private GraphicsDevice[][] screens = {{}};
	private ReentrantLock fairScreenAccess = new ReentrantLock(true);
	private ServerCenter serverCenter = null;
	private HashMap<GraphicsDevice, ScreenManager> screenManagers = new HashMap<GraphicsDevice, ScreenManager>();
	private Semaphore sema = new Semaphore(0);
	private volatile boolean refreshing = false;
	
	public ScreenCenter() {
		MouseObserver.getInstance().addMouseMoveListener(new MouseMoveListener() {
			public void mouseMoved(PointerInfo info) {
				//System.out.println("Mouse moved");
				// find the screen that is receiving this event
				// and then make it fire
				// all other screens must fire the mouse_gone event
				boolean hostScreenFound = false;
				fairScreenAccess.lock();
				try {synchronized(screens) {
					for (GraphicsDevice screen : screens[0]) {
						ScreenManager scm = screenManagers.get(screen);
						if (scm == null || !scm.isAlive()) {
							continue;
						}
						if (hostScreenFound) {
							scm.mouseGone();
						}
						else {
							hostScreenFound = (info.getDevice() == screen);
							if (hostScreenFound) {
								scm.mouseMoved(info.getLocation());
							}
							else {
								scm.mouseGone();
							}
						}
					}
				}}
				finally {
					fairScreenAccess.unlock();
				}
			}
		});
		
	}
	
	public void setServerCenter(ServerCenter serverCenter) {
		this.serverCenter = serverCenter;
	}
	
	public void run() {
		while(!disposed) {
			refresh();
			try {
				sema.acquire();
			} catch (InterruptedException e) {
				e.printStackTrace();
				die();
			}
		}
	}
	
	public int getNumScreens() {
		fairScreenAccess.lock();
		try {synchronized(screens) {
			return screens[0].length;
		}}
		finally {
			fairScreenAccess.unlock();
		}
	}
	
	public boolean pairClientAndScreen(ClientHandler client, int idx) {
		if (idx >= 0) {
			fairScreenAccess.lock();
			try {synchronized(screens) {
				if (idx < screens[0].length) {
					ScreenManager scm = screenManagers.get(screens[0][idx]);
					if (scm != null) {
						try {
							scm.addClient(client);
						} catch (ObjectDisposedException e) {
							e.printStackTrace();
							return false;
						}
						return true;
					}
				}
			}}
			finally {
				fairScreenAccess.unlock();
			}
		}
		return false;
	}
	
	public void die() {
		disposed = true;
		sema.release();
	}
	
	public void refreshAsync() throws ObjectDisposedException {
		if (disposed) {
			throw new ObjectDisposedException("DesktopImageBuffer is dead!");
		}
		if (!refreshing) {
			sema.release();
		}
	}
	
	private void refresh() {
		refreshing = true;
		fairScreenAccess.lock();
		try {synchronized(screens) {
			screens[0] = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
		}}
		finally {
			fairScreenAccess.unlock();
		}
		ScreenManager tmp = null;
		boolean addedScreen = false;
		// keep track of devices that magically "go away" and kill their managers
		HashMap<GraphicsDevice, ScreenManager> oldScreenManagers = new HashMap<GraphicsDevice, ScreenManager>(screenManagers.size());
		oldScreenManagers.putAll(screenManagers);
		for (GraphicsDevice dev : screens[0]) {
			oldScreenManagers.remove(dev);
			if ((addedScreen = (tmp = screenManagers.get(dev)) == null) || !tmp.isAlive()) {
				tmp = null;
				try {
					tmp = new ScreenManager(dev);
				} catch (AWTException e) {
					e.printStackTrace();
				}
				if (tmp != null) {
					tmp.start();
					screenManagers.put(dev, tmp);
				}
			}
		}
		for (Entry<GraphicsDevice, ScreenManager> entry : oldScreenManagers.entrySet()) {
			screenManagers.remove(entry.getKey());
			ScreenManager screenManager = entry.getValue();
			if (screenManager != null) {
				screenManager.die();
			}
		}
		oldScreenManagers = null;
		if (addedScreen) {
			notify(CommandCenter.NOTIFY_COMMAND.NEW_SCREEN);
		}
		refreshing = false;
	}

	public boolean refreshScreenBuffer(int idx) throws AWTException, ObjectDisposedException {
		if (disposed) {
			throw new ObjectDisposedException("DesktopImageBuffer is dead!");
		}
		if (idx >= 0) {
			fairScreenAccess.lock();
			try {synchronized(screens) {
				if (idx < screens[0].length) {
					ScreenManager scm = screenManagers.get(screens[0][idx]);
					if (scm != null) {
						try {
							scm.refresh();
						}
						catch (ObjectDisposedException e) {
							return false;
						}
						return true;
					}
				}
			}}
			finally {
				fairScreenAccess.unlock();
			}
		}
		return false;
	}
	
	public void notify(CommandCenter.NOTIFY_COMMAND command, Object payload) {
		if (serverCenter == null) {
			return;
		}
		serverCenter.lock();
		try {
			for (ClientHandler client : serverCenter.connectedClients) {
				client.notify(command, payload);
			}
		}
		finally {
			serverCenter.unlock();
		}
	}
	
	public void notify(CommandCenter.NOTIFY_COMMAND command) {
		notify(command, null);
	}
	
	public BufferedImage getScreen(int idx) {
		if (disposed) {
			return null;
		}
		if (idx >= 0) {
			fairScreenAccess.lock();
			try {synchronized(screens) {
				if (idx < screens[0].length) {
					ScreenManager scm = screenManagers.get(screens[0][idx]);
					return scm.getScreenshot();
				}
			}}
			finally {
				fairScreenAccess.unlock();
			}
		}
		return null;
	}
	
}