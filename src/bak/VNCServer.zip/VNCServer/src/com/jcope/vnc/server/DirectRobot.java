package com.jcope.vnc.server;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.peer.MouseInfoPeer;
import java.awt.peer.RobotPeer;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

import sun.awt.ComponentFactory;

import com.jcope.ui.DirectBufferedImage;

public final class DirectRobot
{
	public DirectRobot() throws AWTException
	{
		this(null);
	}

	public DirectRobot(GraphicsDevice device) throws AWTException
	{
		if (device == null)
			device = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
		
		ArrayList<Exception> exceptions = new ArrayList<Exception>();

		this.device = device;
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		peer = ((ComponentFactory) toolkit).createRobot(null, device);
		Class<?> peerClass = peer.getClass();
		Method method = null;
		int methodType = -1;
		Object methodParam = null;
		try
		{
			method = peerClass.getDeclaredMethod("getRGBPixels", new Class<?>[] { Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, int[].class });
			methodType = 0;
		} catch (SecurityException e) {
			exceptions.add(e);
		} catch (NoSuchMethodException e) {
			exceptions.add(e);
		}
		if (methodType < 0)
			try
			{
				method = peerClass.getDeclaredMethod("getScreenPixels", new Class<?>[] { Rectangle.class, int[].class });
				methodType = 1;
			} catch (SecurityException e) {
				exceptions.add(e);
			} catch (NoSuchMethodException e) {
				exceptions.add(e);
			}

		if (methodType < 0)
			try
			{
				method = peerClass.getDeclaredMethod("getScreenPixels", new Class<?>[] { Integer.TYPE, Rectangle.class, int[].class });
				methodType = 2;
				GraphicsDevice[] devices = GraphicsEnvironment.getLocalGraphicsEnvironment().
getScreenDevices();
				int count = devices.length;
				for (int i = 0; i != count; ++i)
				{
					if (device.equals(devices[i]))
					{
						methodParam = Integer.valueOf(i);
						break;
					}
				}

			} catch (SecurityException e) {
				exceptions.add(e);
			} catch (NoSuchMethodException e) {
				exceptions.add(e);
			}

		if (methodType < 0)
			try
			{
				boolean accessible = false;
				
				method = peerClass.getDeclaredMethod("getRGBPixelsImpl", new Class<?>[] { Class.forName("sun.awt.X11GraphicsConfig"), Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, int[].class });
				methodType = 3;
				Field field = peerClass.getDeclaredField("xgc");
				try
				{
					field.setAccessible(true);
					accessible = true;
					methodParam = field.get(peer);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					if (accessible)
					{
						field.setAccessible(false);
					}
				}
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchFieldException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		if (methodType >= 0 && method != null && (methodType <= 1 || methodParam != null))
		{
			System.out.println("Method type = " + methodType);
			getRGBPixelsMethod = method;
			getRGBPixelsMethodType = methodType;
			getRGBPixelsMethodParam = methodParam;
		}
		else
		{
			for (Exception e : exceptions)
			{
				e.printStackTrace();
			}
			exceptions.clear();
			exceptions = null;
			System.out.println("WARNING: Failed to acquire direct method for grabbing pixels, please post this on the main thread!");
			System.out.println();
			System.out.println(peer.getClass().getName());
			System.out.println();
			try {
				Method[] methods = peer.getClass().getDeclaredMethods();
				for (Method method1 : methods)
				{
					System.out.println(method1);
				}
	
				System.out.println();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	public static GraphicsDevice getMouseInfo(Point point)
	{
		if (!hasMouseInfoPeer)
		{
			hasMouseInfoPeer = true;
			try
			{
				Toolkit toolkit = Toolkit.getDefaultToolkit();
				Method method = toolkit.getClass().getDeclaredMethod("getMouseInfoPeer", new Class<?>[0]);
				try
				{
					method.setAccessible(true);
					mouseInfoPeer = (MouseInfoPeer) method.invoke(toolkit, new Object[0]);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					method.setAccessible(false);
				}
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (mouseInfoPeer != null)
		{
			int device = mouseInfoPeer.fillPointWithCoords(point != null ? point:new Point());
			GraphicsDevice[] devices = GraphicsEnvironment.getLocalGraphicsEnvironment().
getScreenDevices();
			return devices[device];
		}
		PointerInfo info = MouseInfo.getPointerInfo();
		if (point != null)
		{
			Point location = info.getLocation();
			point.x = location.x;
			point.y = location.y;
		}
		return info.getDevice();
	}

	public static int getNumberOfMouseButtons()
	{
		return MouseInfo.getNumberOfButtons();
	}

	public static GraphicsDevice getDefaultScreenDevice()
	{
		return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
	}
	
	public static GraphicsDevice getScreenDevice()
	{
		return getMouseInfo(null);
	}
	
	public Rectangle getScreenBounds()
	{
		return device.getDefaultConfiguration().getBounds();
	}

	public void mouseMove(int x, int y)
	{
		peer.mouseMove(x, y);
	}

	public void mousePress(int buttons)
	{
		peer.mousePress(buttons);
	}

	public void mouseRelease(int buttons)
	{
		peer.mouseRelease(buttons);
	}

	public void mouseWheel(int wheelAmt)
	{
		peer.mouseWheel(wheelAmt);
	}

	public void keyPress(int keycode)
	{
		peer.keyPress(keycode);
	}

	public void keyRelease(int keycode)
	{
		peer.keyRelease(keycode);
	}

	public int getRGBPixel(int x, int y)
	{
		return peer.getRGBPixel(x, y);
	}

	public int[] getRGBPixels(Rectangle bounds)
	{
		return peer.getRGBPixels(bounds);
	}

	public static void getRGBPixelSlice(int[] src, int srcWidth, int srcHeight, int x, int y, int width, int height, int[] dst)
	{
		assert(width > 0);
		assert(height > 0);
		assert(srcWidth > width);
		assert(srcHeight > height);
		
		int srcPos = y * srcWidth + x;
		int dstPos = 0;
		
		for (int i=0; i<height; i++)
		{
			System.arraycopy(src, srcPos, dst, dstPos, width);
			srcPos += srcWidth;
			dstPos += width;
		}
	}
	
	private ReentrantLock methLock = new ReentrantLock(true);
	public boolean getRGBPixels(int x, int y, int width, int height, int[] pixels)
	{
		if (getRGBPixelsMethod != null)
			try
			{
				switch(getRGBPixelsMethodType)
				{
					case 0:
						getRGBPixelsMethod.invoke(peer, new Object[] { Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(width), Integer.valueOf(height), pixels });
						break;
					case 1:
						getRGBPixelsMethod.invoke(peer, new Object[] { new Rectangle(x, y, width, height), pixels });
						break;
					case 2:
						getRGBPixelsMethod.invoke(peer, new Object[] { getRGBPixelsMethodParam, new Rectangle(x, y, width, height), pixels });
						break;
					default:
						methLock.lock();
						try
						{
							synchronized(getRGBPixelsMethod)
							{
								getRGBPixelsMethod.setAccessible(true);
								try {
									getRGBPixelsMethod.invoke(peer, new Object[] { getRGBPixelsMethodParam, Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(width), Integer.valueOf(height), pixels });
								}
								finally {
									getRGBPixelsMethod.setAccessible(false);
								}
							}
						}
						finally {
							methLock.unlock();
						}
						break;
				}

				return true;
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		int[] tmp = getRGBPixels(new Rectangle(x, y, width, height));
		System.arraycopy(tmp, 0, pixels, 0, width * height);
		return false;
	}

	public void dispose()
	{
		getRGBPixelsMethodParam = null;
		Method method = getRGBPixelsMethod;
		try {
			if (method != null)
			{
				getRGBPixelsMethod = null;
				method.setAccessible(false);
			}
		}
		finally {
			//Using reflection now because of some peers not having ANY support at all (1.5)
			try
			{
				Class<?>[] tailSig = new Class<?>[0];
				peer.getClass().getDeclaredMethod("dispose", tailSig).invoke(peer, (Object[])tailSig);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	protected void finalize() throws Throwable
	{
		try
		{
			dispose();
		}
		finally
		{
			super.finalize();
		}
	}
	
	ReentrantLock cacheSyncLock = new ReentrantLock(true);
	
	public void clearBufferedImage(int[] pixels)
	{
		cacheSyncLock.lock();
		try {
			synchronized(alphaCache){synchronized(nonAlphaCache){
				alphaCache.remove(pixels);
				nonAlphaCache.remove(pixels);
			}}
		}
		finally {
			cacheSyncLock.unlock();
		}
	}
	
	public BufferedImage getBufferedImage(int[] pixels, int size, int width, int height, boolean hasAlpha) {
		BufferedImage image = null;
		
		assert(size > 0);
		assert(width > 0);
		assert(height > 0);
		assert(size == (width * height));
		assert(pixels.length >= size);
		
		cacheSyncLock.lock();
		try {
			synchronized(alphaCache){synchronized(nonAlphaCache){
				image = (hasAlpha ? alphaCache : nonAlphaCache).get(pixels);
				
				if (image == null)
				{
					image = new DirectBufferedImage(pixels, size, width, height, hasAlpha);
					
					/*
					// TO DO: enhance such that the new image uses the int[] without creating copy
					image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
					image.setRGB(0, 0, width, height, pixels, 0, width);
					*/
					
					(hasAlpha ? alphaCache : nonAlphaCache).put(pixels, image);
				}
			}}
		}
		finally {
			cacheSyncLock.unlock();
		}
		
		return image;
	}
	
	private Object getRGBPixelsMethodParam;
	private int getRGBPixelsMethodType;
	public final GraphicsDevice device;
	private Method getRGBPixelsMethod;
	private final RobotPeer peer;
	private static boolean hasMouseInfoPeer;
	private static MouseInfoPeer mouseInfoPeer;
	private WeakHashMap<int[],BufferedImage> nonAlphaCache = new WeakHashMap<int[],BufferedImage>();
	private WeakHashMap<int[],BufferedImage> alphaCache = new WeakHashMap<int[],BufferedImage>();
}