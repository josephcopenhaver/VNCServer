package com.jcope.vnc.server;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import com.jcope.remote.CommandCenter;
import com.jcope.util.ObjectDisposedException;
import com.jcope.vnc.RemoteInterface;



/**
 * Delegates between subscribers and screens and screen cells
 * 
 * 
 * @author x0140937
 *
 */
public class ScreenManager extends Thread {
	
	private static final boolean DEBUG = false;
	
	private static final boolean debugAllowSlices = true;
	
	// standard screen members
	//private GraphicsDevice screen;
	private Robot _screenBot;
	private ArrayList<ClientHandler> listeningClients = new ArrayList<ClientHandler>();
	private volatile boolean disposed = false;
	private Semaphore beingWatched = new Semaphore(0);
	private volatile int[] screenShot = new int[0];
	private DirectRobot dirbot = null;
	private volatile int dx = 0;
	private volatile int dy = 0;
	private volatile boolean sleeping = false;
	private volatile boolean mouseOnScreen = false;
	private ReentrantLock fairClientsAccess = new ReentrantLock(true);
	
	
	// dynamic programming enhancements for tile management
	private static final int sliceSideLength = 128*2;
	private static final Dimension sliceSize = new Dimension(sliceSideLength, sliceSideLength);
	private volatile boolean hasAlpha = false; // TODO: detect alpha properly, confirm if need be volatile
	private ArrayList<int[]>screenSlices = null;
	private int numSlicesInScreenSlices = 0;
	private int mNumHorizontalTiles = 0;
	private int numHorizontalTiles = 0;
	private int numVerticalTiles = 0;
	private int bottomRowHeight = 0;
	private int rightColumnWidth = 0;
	private int normalTileSize = 0;
	private int rightTileSize = 0;
	private int bottomTileSize = 0;
	private int bottomRightTileSize = 0;
	private int[] tmpTileSlice = new int[0];
	private int numTiles = 0;
	
	
	private long[] refreshMS = {VNCServerConfig.defaultRefreshMS};

	public ScreenManager(GraphicsDevice graphicsDevice) throws AWTException {
		//this.screen = graphicsDevice;
		_screenBot = new Robot(graphicsDevice);
		dirbot = new DirectRobot(graphicsDevice);
	}
	
	public void run() {
		long lastRanAt;
		boolean mustSleep = false;
		while (!disposed) {
			fairClientsAccess.lock();
			try {synchronized(listeningClients) {
				if (listeningClients.size() == 0) {
					sleeping = true;
					mustSleep = true;
				}
			}}
			finally {
				fairClientsAccess.unlock();
			}
			if (mustSleep) {
				try {
					beingWatched.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
					die();
				}
				if (disposed) {
					break;
				}
				mustSleep = false;
			}
			
			lastRanAt = System.currentTimeMillis();
			
			try {
				refresh();
			}
			catch (Exception e) {
				e.printStackTrace();
				break;
			}
			
			try {
				Long sleepTime;
				synchronized(refreshMS) {
					sleepTime = refreshMS[0];
				}
				sleepTime = sleepTime - (System.currentTimeMillis() - lastRanAt);
				if (sleepTime > 0)
				{
					Thread.sleep(sleepTime);
				}
				else
				{
					System.err.println("Holy crap, going full throttle!");
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
				die();
			}
		}
	}
	
	public void setRefreshMS(long ms) {
		synchronized(refreshMS) {
			refreshMS[0] = ms;
		}
	}
	
	public void minimizeRefreshMS(long msCandidate) {
		synchronized(refreshMS) {
			if (msCandidate < refreshMS[0]) {
				refreshMS[0] = msCandidate;
			}
		}
	}
	
	public void die() {
		disposed = true;
		beingWatched.release();
		RemoteInterface.unregister(this);
		fairClientsAccess.lock();
		try {synchronized(listeningClients) {
			for (ClientHandler client : listeningClients) {
				client.destroy();
			}
		}}
		finally {
			fairClientsAccess.unlock();
		}
	}
	
	private int[] tmpScreen = null;
	private int numPixels = 0;
	public void refresh() throws ObjectDisposedException {
		//System.out.println("Refreshing screen");
		if (disposed) {
			throw new ObjectDisposedException("ScreenManager is dead!");
		}
		//Rectangle screenBounds = screen.getDefaultConfiguration().getBounds();
		Rectangle screenBounds = dirbot.getScreenBounds();
		boolean newScreenSize = false;
		if (screenBounds.width != dx || screenBounds.height != dy) {
			dx = screenBounds.width;
			dy = screenBounds.height;
			numPixels = dx * dy;
			newScreenSize = true;
		}
		screenBounds.x = 0;
		screenBounds.y = 0;
		
		// using a buffered image instead of using the robot to compare pixels is way damn faster!
		
		// since the screenbot is now used for inputing user data,
		// would it be wise to make it synchronized when used?
		//synchronized(screenBot) {
		if (tmpScreen == null || tmpScreen.length < numPixels)
		{
			tmpScreen = new int[numPixels];
		}
		dirbot.getRGBPixels(0, 0, dx, dy, tmpScreen);
		//}
		//if (screenShot != null) {
		//	screenShot.flush();
		//}
		handleScreenShot(newScreenSize, tmpScreen);
	}
	
	private boolean isPastSliceSendingThreshold(int numNew, int numInSet)
	{
		
		if (numNew > (numInSet * 2 / 3))
		{
			return true;
		}
		
		return false;
	}
	
	private void debugSaveImage(int idx, int[] slice, int width, int height)
	{
		if (!DEBUG)
		{
			return;
		}
		System.out.println("Saving img " + idx);
		String ext = "png";
		File file = new File(String.format("img_%d.%s", idx, ext));
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		//WritableRaster data = (WritableRaster) img.getData();
		//data.setPixels(0, 0, width, height, slice);
		img.setRGB(0, 0, width, height, slice, 0, width);
		try {
			System.out.println(file.getAbsolutePath());
			boolean worked = ImageIO.write(img, ext, file);
			assert(worked);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void handleScreenShot(boolean newScreenSize, int[] newScreen) {
		int[] tileInfo = new int[7];
		
		if (screenShot.length < numPixels)
		{
			screenShot = Arrays.copyOf(newScreen, numPixels);
		}
		//else
		//{
		//	// TODO: look into doing this piecewise on diff tile detection
		//	System.arraycopy(newScreen, 0, screenShot, 0, newScreen.length);
		//}
		
		HashMap<Integer, int[]> newSlices;
		if (newScreenSize) {
			int[] slice;
			
			newSlices = null;
			// reinit buckets
			numHorizontalTiles = (int) Math.ceil(((double)dx)/sliceSize.getWidth());
			numVerticalTiles = (int) Math.ceil(((double)dy)/sliceSize.getHeight());
			numTiles = numHorizontalTiles * numVerticalTiles;
			mNumHorizontalTiles = numHorizontalTiles - 1;
			screenSlices = new ArrayList<int[]>(numTiles);
			rightColumnWidth = dx - ((numHorizontalTiles - 1) * sliceSize.width);
			bottomRowHeight = dy - ((numVerticalTiles - 1) * sliceSize.height);
			normalTileSize = sliceSize.width * sliceSize.height;
			if (tmpTileSlice.length < normalTileSize)
			{
				tmpTileSlice = new int[normalTileSize];
			}
			rightTileSize = rightColumnWidth * sliceSize.height;
			bottomTileSize = sliceSize.width * bottomRowHeight;
			bottomRightTileSize = rightColumnWidth * bottomRowHeight;
			boolean debugSlice = false;
			for (int idx=0; idx < numTiles; idx++) {
				debugSlice = false;
				getTileInfoFromID(idx, tileInfo);
				if (idx < numSlicesInScreenSlices)
				{
					slice = screenSlices.get(idx);
					if (slice.length < tileInfo[6])
					{
						slice = new int[tileInfo[6]];
						screenSlices.set(idx, slice);
					}
				}
				else
				{
					slice = new int[tileInfo[6]];
					screenSlices.add(idx, slice);
					numSlicesInScreenSlices++;
					debugSlice = true;
				}
				DirectRobot.getRGBPixelSlice(newScreen, dx, dy, tileInfo[2], tileInfo[3], tileInfo[4], tileInfo[5], slice);
				if (DEBUG && debugSlice)
				{
					debugSaveImage(idx, slice, tileInfo[4], tileInfo[5]);
				}
			}
		}
		else {
			newSlices = new HashMap<Integer, int[]>();
			for (int idx=0; idx < numTiles; idx++) {
				getTileInfoFromID(idx, tileInfo);
				if (!sameImageOnScreen(newScreen, tileInfo[2], tileInfo[3], tileInfo[4], tileInfo[5], screenSlices.get(idx))) {
					int[] newSlice = new int[tileInfo[6]];
					DirectRobot.getRGBPixelSlice(newScreen, dx, dy, tileInfo[2], tileInfo[3], tileInfo[4], tileInfo[5], newSlice);
					screenSlices.set(idx, newSlice);
					newSlices.put(idx, newSlice);
				}
			}
		}
		boolean newImageDeltas;
		if (newSlices == null) {
			newImageDeltas = true;
		}
		else {
			int numNew = newSlices.size();
			newImageDeltas = numNew > 0;
			if ((newImageDeltas && isPastSliceSendingThreshold(numNew, numTiles)) || !debugAllowSlices) {
				// just send the whole damn screen
				//System.out.println("Too many screen slices to send, just sending the whole screen!");
				newSlices = null;
			}
			if (newImageDeltas)
			{
				assert(newScreen.length == screenShot.length);
				System.arraycopy(newScreen, 0, screenShot, 0, newScreen.length);
			}
		}
		if (newImageDeltas) {
			fairClientsAccess.lock();
			try {synchronized(listeningClients) {
				//final boolean fNewScreenSize = newScreenSize;
				long now = System.currentTimeMillis();
				for (ClientHandler client : listeningClients) {
					if (newScreenSize) {
						notifyClientOfScreenSizeChange(client);
					}
					if (newImageDeltas) {
						client.deferImageFlush(now);
						if (newSlices == null) {
							client.sendFullJpegImage(getScreenshot()); // non-blocking
						}
						else {
							//System.out.println("before targetClient.sendJpegImageDeltas(newSlices);");
							client.sendJpegImageDeltas(this, newSlices);
						}
						client.ensureOutboundImageBufferCapacity();
					}
				}
			}}
			finally {
				fairClientsAccess.unlock();
			}
		}
	}
	
	public void notifyClientOfScreenSizeChange(ClientHandler client) {
		client.notify(CommandCenter.NOTIFY_COMMAND.SCREEN_DIMENSIONS_CHANGED, _getMetaData()); // non-blocking
	}
	
	private int[] _getMetaData() {
		return new int[]{dx, dy, sliceSize.width, sliceSize.height};
	}
	
	public int[] getMetaData() {
		if (screenSlices == null) {
			return null;
		}
		return new int[]{dx, dy, sliceSize.width, sliceSize.height};
	}
	
	private int[] tmpScreenRow = new int[0];
	private int[] tmpTileRow = new int[0];
	public boolean sameImageOnScreen(int[] screen, int xoff, int yoff, int width, int height, int[] tile) {
		
		int screenPos = yoff * dx + xoff;
		int tilePos = 0;
		
		if (tmpTileRow.length < width)
		{
			tmpTileRow = new int[width];
			tmpScreenRow = new int[width];
		}
		
		for (int heightPos = 0; heightPos < height; heightPos++)
		{
			/*
			for (int widthPos = 0; widthPos < tileInfo[4]; widthPos++)
			{
				if (screen[screenPos + widthPos] != tile[tilePos + widthPos])
				{
					return false;
				}
			}
			*/
			
			System.arraycopy(screen, screenPos, tmpScreenRow, 0, tmpScreenRow.length);
			System.arraycopy(tile, tilePos, tmpTileRow, 0, tmpTileRow.length);
			
			if (!Arrays.equals(tmpTileRow, tmpScreenRow))
			{
				return false;
			}
			
			tilePos += width;
			screenPos += dx;
		}
		
		return true;
		
		/*
		if (height != b.getHeight() || width != b.getWidth()) {
			return false;
		}
		// CPU does WAY too much when there is NO change
		/*
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				if (a.getRGB(x, y) != b.getRGB(x, y)) {
					return false;
				}
			}
		}
		/
		int numRandomPointsToSample = Math.max(width, height)/9;
		if (numRandomPointsToSample < 3)
		{
			numRandomPointsToSample = 3;
		}
		int randx, randy;
		for (int iter = 0; iter < numRandomPointsToSample; iter++) {
			randx = (int) Math.floor(Math.random()*((double)(width)));
			randy = (int) Math.floor(Math.random()*((double)(height)));
			//if (randx >= width || randy >= height) {
			//	System.out.println(String.format("(%d,%d) ~within [%d,%d]", randx, randy, width, height));
			//}
			if (a.getRGB(randx + xoff, randy + yoff) != b.getRGB(randx, randy)) {
				//System.out.println("Images differ - " + numRandomPointsToSample);
				return false;
			}
		}
		//System.out.println("Images same - " + numRandomPointsToSample);
		return true;
		*/
	}
	
	public void addClient(ClientHandler client) throws ObjectDisposedException {
		if (disposed) {
			throw new ObjectDisposedException("ScreenManager is dead!");
		}
		boolean wakeUpNeeded = false;
		fairClientsAccess.lock();
		try {synchronized(listeningClients) {
			if (sleeping) {
				wakeUpNeeded = true;
			}
			client.setScreenManager(this);
			listeningClients.add(client);
		}}
		finally {
			fairClientsAccess.unlock();
		}
		if (wakeUpNeeded) {
			sleeping = false;
			beingWatched.release();
		}
	}
	
	public void removeClient(ClientHandler client) throws ObjectDisposedException {
		if (disposed) {
			throw new ObjectDisposedException("ScreenManager is dead!");
		}
		fairClientsAccess.lock();
		try {synchronized(listeningClients) {
			listeningClients.remove(client);
			long newRefreshMS = Long.MAX_VALUE;
			for (ClientHandler lc : listeningClients) {
				long rfms = lc.getRefreshMS();
				if (rfms < newRefreshMS) {
					newRefreshMS = rfms;
				}
			}
			if (newRefreshMS == Long.MAX_VALUE) {
				newRefreshMS = VNCServerConfig.defaultRefreshMS;
			}
			synchronized(refreshMS) {
				refreshMS[0] = newRefreshMS;
			}
		}}
		finally {
			fairClientsAccess.unlock();
		}
	}
	
	public BufferedImage getScreenshot() {
		if (screenShot.length == 0)
		{
			return null;
		}
		if (DEBUG)
		{
			debugSaveImage(-1, screenShot, dx, dy);
		}
		return dirbot.getBufferedImage(screenShot, numPixels, dx, dy, hasAlpha);
	}
	
	public void mouseMoved(Point p) {
		mouseOnScreen = true;
		fairClientsAccess.lock();
		try {synchronized(listeningClients) {
			for (ClientHandler client : listeningClients) {
				client.notifyMouseMove(p);
			}
		}}
		finally {
			fairClientsAccess.unlock();
		}
	}
	
	public void mouseGone() {
		if (mouseOnScreen) {
			mouseOnScreen = false;
			fairClientsAccess.lock();
			try {synchronized(listeningClients) {
				for (ClientHandler client : listeningClients) {
					client.notify(CommandCenter.NOTIFY_COMMAND.MOUSE_MOVE, null);
				}
			}}
			finally {
				fairClientsAccess.unlock();
			}
		}
	}
	
	public Robot getRobot() {
		return _screenBot;
	}
	
	public GraphicsDevice getGraphicsDevice() {
		return dirbot.device;
	}

	public boolean getTileInfoFromID(int id, int[] info) {
		assert(info.length >= 7);
		assert(id < numTiles);
		
		if (id >= numTiles || info.length < 7)
		{
			return false;
		}
		
		int xTile = id % numHorizontalTiles;
		int yTile = id / numHorizontalTiles;
		boolean atRightEdge = (xTile == mNumHorizontalTiles);
		boolean atBottomEdge = (numTiles - id <= numHorizontalTiles);
		int tileWidth = atRightEdge ? rightColumnWidth : sliceSize.width;
		int tileHeight = atBottomEdge ? bottomRowHeight : sliceSize.height;
		int srcx = xTile * sliceSize.width;
		int srcy = yTile * sliceSize.height;
		int numPixInTile = (atRightEdge ? (atBottomEdge ? bottomRightTileSize : rightTileSize) : (atBottomEdge ? bottomTileSize : normalTileSize));
		
		info[0] = xTile;
		info[1] = yTile;
		info[2] = srcx;
		info[3] = srcy;
		info[4] = tileWidth;
		info[5] = tileHeight;
		info[6] = numPixInTile;
		
		return true;
	}

	public BufferedImage getBufferedTile(int id, int[] tile, int[] tileInfo) {
		BufferedImage rval;
		
		if (getTileInfoFromID(id, tileInfo))
		{
			rval = dirbot.getBufferedImage(tile, tileInfo[6], tileInfo[4], tileInfo[5], hasAlpha);
		}
		else
		{
			rval = null;
		}
		
		return rval;
	}
	
}