package com.jcope.remote;

import java.util.HashMap;

import com.jcope.remote.RemoteCallCenter;

/**
 * Holds Net I/O type declarations
 * 
 * @author x0140937
 *
 */

public class CommandCenter {
	
	private static final HashMap<Byte, NOTIFY_COMMAND> notifyCommandLookup = new HashMap<Byte, NOTIFY_COMMAND>();
	private static final HashMap<Byte, REQUEST_COMMAND> requestCommandLookup = new HashMap<Byte, REQUEST_COMMAND>();
	private static byte notifyCommandCtr = 0;
	private static byte requestCommandCtr = 0;
	
	public static enum NOTIFY_COMMAND {
		NEW_SCREEN,
		SCREEN_DIMENSIONS_CHANGED,
		MOUSE_MOVE,
		UNAUTHORIZED,
		AUTHORIZED,
		ACCESS_DENIED;
		
		
		
		private byte code;
		
		NOTIFY_COMMAND() {
			notifyCommandCtr++;
			code = notifyCommandCtr;
			notifyCommandLookup.put(code, this);
		}
		
		public static boolean isInstance(byte code) {
			return notifyCommandLookup.get(code) != null;
		}
		
		public byte getCode() {
			return code;
		}
	}
	
	public static enum REQUEST_COMMAND {
		GET_NUM_SCREENS,
		SELECT_SCREEN,
		GET_SCREEN,
		AUTHORIZATION,
		CONFIRM;
		
		
		
		private byte code;
		
		REQUEST_COMMAND() {
			requestCommandCtr--;
			code = requestCommandCtr;
			requestCommandLookup.put(code, this);
		}
		
		public static boolean isInstance(byte code) {
			return requestCommandLookup.get(code) != null;
		}
		
		public byte getCode() {
			return code;
		}
	}
	
	public static String getCommandTypeName(byte msgTypeCode, byte code) {
		if (msgTypeCode == RemoteCallCenter.MSG_TYPE.NOTIFY.getCode()) {
			for (NOTIFY_COMMAND t : NOTIFY_COMMAND.values()) {
				if (t.code == code) {
					return t.name();
				}
			}
		}
		else if (msgTypeCode == RemoteCallCenter.MSG_TYPE.REPLY.getCode()) {
			//nada
		}
		else if (msgTypeCode == RemoteCallCenter.MSG_TYPE.REQUEST.getCode()) {
			for (REQUEST_COMMAND t : REQUEST_COMMAND.values()) {
				if (t.code == code) {
					return t.name();
				}
			}
		}
		return "NONE";
	}
	
}