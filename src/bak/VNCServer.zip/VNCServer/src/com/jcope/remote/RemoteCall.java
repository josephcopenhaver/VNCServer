package com.jcope.remote;

import java.io.Serializable;

public class RemoteCall implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public int msgID;
	public byte msgType;
	public byte commandType;
	public Object payload;

}