package com.jcope.remote;

import com.jcope.remote.RemoteCall;

import java.util.HashMap;



public class RemoteCallCenter {
	
	private static byte enumCtr = 0;
	
	public static enum MSG_TYPE {
		NOTIFY,
		REPLY,
		REQUEST;
		
		
		
		private byte code;
		
		MSG_TYPE() {
			enumCtr++;
			code = enumCtr;
		}
		
		public byte getCode() {
			return code;
		}
	}
	
	public HashMap<Integer, Callback> callbackRegistry = new HashMap<Integer, Callback>();
	
	private static Integer requestIDCtr = 1;
	private static Integer notifyIDCtr = 1;
	
	public static String getMessageTypeName(byte code) {
		for (MSG_TYPE t : MSG_TYPE.values()) {
			if (t.code == code) {
				return t.name();
			}
		}
		return "NONE";
	}
	
	public static int getNextNotifyID() {
		int rval;
		synchronized(notifyIDCtr) {
			rval = notifyIDCtr;
			notifyIDCtr++;
			if (notifyIDCtr <= 0) {
				notifyIDCtr = 1;
			}
		}
		return rval;
	}
	
	public static int getNextRequestID() {
		int rval;
		synchronized(requestIDCtr) {
			rval = requestIDCtr;
			requestIDCtr++;
			if (requestIDCtr <= 0) {
				requestIDCtr = 1;
			}
		}
		return rval;
	}
	
	public boolean handleResponse(RemoteCall reply) {
		if (reply.msgType == MSG_TYPE.REPLY.getCode()) {
			Callback callback = callbackRegistry.remove(reply.msgID);
			if (callback != null) {
				callback.run(reply);
				return true;
			}
		}
		return false;
	}
	
	public void reset() {
		requestIDCtr = 1;
		notifyIDCtr = 1;
		callbackRegistry.clear();
	}
	
}