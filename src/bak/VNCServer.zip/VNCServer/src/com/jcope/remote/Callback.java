package com.jcope.remote;


public class Callback {
	
	private Runnable runnable;
	private RemoteCall[] args;
	
	public Callback(Runnable runnable, RemoteCall[] args) {
		this.runnable = runnable;
		this.args = args;
	}
	
	public Callback(Runnable runnable) {
		this(runnable, null);
	}
	
	public void run() {
		if (runnable != null) {
			runnable.run();
		}
	}
	
	public void run(RemoteCall reply) {
		if (args != null) {
			args[0] = reply;
		}
		run();
	}
	
}