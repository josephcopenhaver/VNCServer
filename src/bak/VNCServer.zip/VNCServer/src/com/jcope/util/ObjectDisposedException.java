package com.jcope.util;


public class ObjectDisposedException extends Exception {
	
	private static final long serialVersionUID = -470074543990515952L;
	
	public ObjectDisposedException(String context) {
		super(context);
	}
	
}