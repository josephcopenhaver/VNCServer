package com.jcope.util;

import java.awt.PointerInfo;

public interface MouseMoveListener {
	public void mouseMoved(PointerInfo info);
}