package com.jcope.util;

import java.awt.MouseInfo;
import java.awt.PointerInfo;
import java.util.HashSet;
import java.util.concurrent.Semaphore;

import com.jcope.vnc.server.VNCServerConfig;



public class MouseObserver extends Thread {
	
	private static MouseObserver[] self = {null};
	
	private HashSet<MouseMoveListener> listeners = new HashSet<MouseMoveListener>();
	private PointerInfo info = null;
	
	private boolean running = false;
	private Semaphore runSema = new Semaphore(0, true);
	
	private MouseObserver () {
		start();
	}
	
	public static MouseObserver getInstance() {
		synchronized (self) {
			if (self[0] == null) {
				self[0] = new MouseObserver();
			}
		}
		return self[0];
	}
	
	public void addMouseMoveListener(MouseMoveListener listener) {
		synchronized(listeners) {
			listeners.add(listener);
		}
	}
	
	public void removeMouseMoveListener(MouseMoveListener listener) {
		synchronized(listeners) {
			listeners.remove(listener);
		}
	}
	
	public void run() {
		while (true) {
			try {
				runSema.acquire();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			PointerInfo newInfo = MouseInfo.getPointerInfo();
			if (info == null || newInfo.getDevice() != info.getDevice() || !newInfo.getLocation().equals(info.getLocation())) {
				info = newInfo;
				synchronized (listeners) {
					for (MouseMoveListener listener : listeners) {
						listener.mouseMoved(info);
					}
				}
			}
			try {
				Thread.sleep(VNCServerConfig.defaultMouseUpdateInterval);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			runSema.release();
		}
	}
	
	public synchronized void pause() {
		if (running) {
			running = false;
			try {
				runSema.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public synchronized void unpause() {
		if (!running) {
			running = true;
			runSema.release();
		}
	}
	
	public PointerInfo getPointerInfo() {
		return info;
	}
	
}