package com.jcope.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;



public class TaskDispatcher<T> {
	
	
	class Dispatchable {
		
		public Runnable callback;
		public Semaphore semaphore;
		public OpenLinkedList<T>.Node node;
		
		public Dispatchable(OpenLinkedList<T>.Node node, Runnable callback, Semaphore semaphore) {
			this.node = node;
			this.callback = callback;
			this.semaphore = semaphore;
		}
		
	}
	
	
	public static enum SYNC_CALL_RESULT {NOT_RUN, ERROR, COMPLETE};
	private HashMap<T, Dispatchable> taskRegistry = new HashMap<T, Dispatchable>();
	private HashMap<T, Boolean> immediateTypes = new HashMap<T, Boolean>();
	private HashMap<T, Boolean> deferredTypes = new HashMap<T, Boolean>();
	private OpenLinkedList<T> taskQueue = new OpenLinkedList<T>();
	private LinkedList<Semaphore> threadsWaitingForIdle = new LinkedList<Semaphore>(); 
	private boolean asleep = false;
	private Semaphore semaphore = new Semaphore(0, true);
	private Runnable errorHandler = null;
	private Throwable lastError = null;
	private volatile boolean disposed = false;
	private boolean started = false;
	private volatile int queueSize = 0;
	private ReentrantLock fairLock = new ReentrantLock(true);
	
	Thread dispatcherThread;
	
	public TaskDispatcher() {
		dispatcherThread = new Thread() {
			public void run() {
				Runnable runningCallback = null;
				while (!disposed) {
					fairLock.lock();
					try {synchronized(this) {
						if (queueSize == 0) {
							asleep = true;
						}
						else {
							queueSize--;
							T key = taskQueue.removeFirst();
							runningCallback = taskRegistry.remove(key).callback;
						}
					}}
					finally {
						fairLock.unlock();
					}
					if (runningCallback == null) {
						goToSleep();
						if (disposed) {
							break;
						}
						continue;
					}
					try {
						runningCallback.run();
					}
					catch (Throwable t) {
						handleError(t);
					}
					finally {
						runningCallback = null;
					}
				}
			}
		};
	}
	
	public synchronized void start() {
		if (started) {
			return;
		}
		started = true;
		dispatcherThread.start();
	}
	
	private void _registerCallback(T type, Runnable callback, Semaphore synchronousCallSemaphore) {
		if (type == null) {
			throw new NullPointerException("Type parameter must not be null!");
		}
		fairLock.lock();
		try {synchronized(this) {
			boolean isImmediate = isImmediate(type);
			boolean repositionTask = (isImmediate || synchronousCallSemaphore != null || isDeferred(type));
			Dispatchable previous = taskRegistry.get(type);
			if (previous != null) {
				if (repositionTask || callback == null) {
					taskQueue.removeNode(previous.node);
					queueSize--;
				}
				if (previous.semaphore != null) {
					previous.semaphore.release();
				}
			}
			if (callback == null) {
				taskRegistry.remove(type);
			}
			else if (repositionTask || previous == null) {
				OpenLinkedList<T>.Node current = null;
				if (isImmediate) {
					current = taskQueue.addFirst(type);
				}
				else {
					current = taskQueue.addLast(type);
				}
				taskRegistry.put(type, new Dispatchable(current, callback, synchronousCallSemaphore));
				queueSize++;
				if (asleep) {
					wakeUp();
				}
			}
			else {
				previous.callback = callback;
				previous.semaphore = synchronousCallSemaphore;
			}
		}}
		finally {
			fairLock.unlock();
		}
	}
	
	public void registerCallback(T type, Runnable callback) {
		//synchronized(this) {
			_registerCallback(type, callback, null);
		//}
	}
	
	public SYNC_CALL_RESULT synchronousCall(T type, final Runnable callback) throws InterruptedException {
		final SYNC_CALL_RESULT[] rval = {SYNC_CALL_RESULT.NOT_RUN};
		final Semaphore semaphore = new Semaphore(0);
		Runnable syncCall = new Runnable() {
			public void run() {
				try {
					callback.run();
					synchronized(rval) {
						rval[0] = SYNC_CALL_RESULT.COMPLETE;
					}
				}
				catch (Throwable t) {
					synchronized(rval) {
						rval[0] = SYNC_CALL_RESULT.ERROR;
					}
					handleError(t);
				}
				finally {
					semaphore.release();
				}
			}
		};
		//synchronized(this) {
			_registerCallback(type, syncCall, semaphore);
		//}
		semaphore.acquire();
		synchronized(rval) {
			return rval[0];
		}
	}
	
	public Runnable getRegisteredCallback(T type) {
		fairLock.lock();
		try {synchronized(this) {
			Dispatchable d = taskRegistry.get(type);
			if (d == null) {
				return null;
			}
			return d.callback;
		}}
		finally {
			fairLock.unlock();
		}
	}
	
	public synchronized void setDeferred(T type) {
		deferredTypes.put(type, true);
	}
	
	private boolean isDeferred(T type) {
		Boolean isDeferred = deferredTypes.get(type);
		return (isDeferred != null && isDeferred);
	}
	
	public synchronized void setImmediate(T type) {
		immediateTypes.put(type, true);
	}
	
	private boolean isImmediate(T type) {
		Boolean isDeferred = immediateTypes.get(type);
		return (isDeferred != null && isDeferred);
	}
	
	private void signalIdle() {
		synchronized(threadsWaitingForIdle) {
			while (!threadsWaitingForIdle.isEmpty()) {
				Semaphore semaphore = threadsWaitingForIdle.remove();
				semaphore.release();
			}
		}
	}
	
	public void dispose() {
		disposed = true;
		wakeUp();
	}
	
	private void goToSleep() {
		signalIdle();
		try {
			semaphore.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
			handleError(e);
		}
	}
	
	private void wakeUp() {
		asleep = false;
		semaphore.release();
	}
	
	public void waitForIdlesignal() throws InterruptedException {
		Semaphore semaphore = null;
		synchronized (threadsWaitingForIdle) {
			if (asleep) {
				return;
			}
			else {
				semaphore = new Semaphore(0);
				threadsWaitingForIdle.add(semaphore);
			}
		}
		semaphore.acquire();
	}
	
	public synchronized void setErrorHandler(Runnable errorHandler) {
		this.errorHandler = errorHandler;
	}
	
	public synchronized Runnable getErrorHandler() {
		return errorHandler;
	}
	
	private void handleError(Throwable t) {
		t.printStackTrace();
		lastError = t;
		if (errorHandler != null) {
			errorHandler.run();
		}
	}
	
	public Throwable getLastError() {
		return lastError;
	}
	
}