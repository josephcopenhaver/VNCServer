package com.jcope.util;



public class OpenLinkedList<T> {
	
	
	
	class Node {
		
		private static final String parentingError = "Only the parent OpenLinkedList can modify this object";
		
		private Object pid;
		private T data;
		private Node left = null;
		private Node right = null;
		
		public Node(Object pid, T data) {
			this.pid = pid;
			this.data = data;
		}
		
		public Node(T data) {
			this(null, data);
		}
		
		public T getData() {
			return data;
		}
		
		public Node getLeft() {
			return left;
		}
		
		public Node getRight() {
			return right;
		}
		
		public void setLeft(Object pid, Node node) {
			verifyParentage(pid);
			left = node;
		}
		
		public void setLeft(Node node) {
			setLeft(null, node);
		}
		
		public void setRight(Object pid, Node node) {
			verifyParentage(pid);
			right = node;
		}
		
		public void setRight(Node node) {
			setRight(null, node);
		}
		
		public void verifyParentage(Object pid) {
			if (this.pid != null && this.pid != pid) {
				throw new NullPointerException(parentingError);
			}
		}
		
	}
	
	
	
	private final Object pid = new Object();
	private Node first = null;
	private Node last = null;
	
	public Node addFirst(T data) {
		synchronized(this) {
			Node _first = new Node(pid, data);
			if (last == null) {
				last = _first;
			}
			else {
				_first.setRight(pid, first);
				first.setLeft(pid, _first);
			}
			first = _first;
			return first;
		}
	}
	
	public Node addLast(T data) {
		synchronized(this) {
			Node _last = new Node(pid, data);
			if (first == null) {
				first = _last;
			}
			else {
				_last.setLeft(pid, last);
				last.setRight(pid, _last);
			}
			last = _last;
			return last;
		}
	}
	
	public Node add(T data) {
		return addLast(data);
	}
	
	public T removeNode(Node node) {
		synchronized(this) {
			if (node == first) {
				return removeFirst();
			}
			else if (node == last) {
				return removeLast();
			}
			node.verifyParentage(pid);
			Node left = node.getLeft();
			Node right = node.getRight();
			left.setRight(pid, right);
			right.setLeft(pid, left);
			return node.getData();
		}
	}
	
	public T removeFirst() {
		synchronized(this) {
			if (first == null) {
				throw new NullPointerException();
			}
			Node _first = first;
			if (first == last) {
				first = null;
				last = null;
			}
			else {
				first = first.getRight();
				first.setLeft(pid, null);
			}
			return _first.getData();
		}
	}
	
	public T removeLast() {
		synchronized(this) {
			if (last == null) {
				throw new NullPointerException();
			}
			Node _last = last;
			if (first == last) {
				first = null;
				last = null;
			}
			else {
				last = last.getLeft();
				last.setRight(pid, null);
			}
			return _last.getData();
		}
	}
	
	public int size() {
		synchronized(this) {
			int rval = 0;
			Node node = first;
			while (node != null) {
				node = node.getRight();
				rval++;
			}
			return rval;
		}
	}
	
}