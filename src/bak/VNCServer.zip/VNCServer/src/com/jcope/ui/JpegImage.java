package com.jcope.ui;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.imageio.ImageIO;



public class JpegImage implements Serializable {

	private static final long serialVersionUID = -2511037523652764739L;
	private static final String formatName = "jpeg";
	private int[] binaryImage;
	private int[] info = new int[DirectBufferedImage.INFO_INT_NUM_FIELDS];
	private Object bufferedImage = null;
	private int id;
	
	public JpegImage(int id, BufferedImage image) throws IOException {
		this(image);
		this.id = id;
	}
		
	
	public JpegImage(BufferedImage image) throws IOException {
		assert(image != null);
		id = -1;
		_mark(image);
	}
	
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		if (bufferedImage == null) {
			out.defaultWriteObject();
		}
		else {
			Object bufferedImage = this.bufferedImage;
			this.bufferedImage = null;
			out.defaultWriteObject();
			this.bufferedImage = bufferedImage;
		}
	}
	
	/**
	 * Creates a BufferedImage from the source image.
	 * Note that this image persists until reset() back to the baseline image.
	 * The baseline image can be set via mark([BufferedImage])
	 * 
	 * Only the marked image is serializable.
	 * 
	 * @return
	 * @throws IOException
	 */
	public BufferedImage getImage() throws IOException {
		if (bufferedImage == null) {
			bufferedImage = new DirectBufferedImage(binaryImage, info);
		}
		return (BufferedImage)bufferedImage;
	}
	
	/**
	 * Resets the buffered image back to the last mark'd point (or initial point if never marked)
	 * Only the marked image is serializable.
	 */
	public void reset() {
		bufferedImage = null;
	}
	
	//private static final int[] debugCnt = new int[]{0};
	//
	private void _mark(BufferedImage bufferedImage) throws IOException {
		//debugCnt[0]++;
		//System.out.println("DEBUG_CNT: " + debugCnt[0]);
		//ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		//if (!ImageIO.write(bufferedImage, formatName, buffer)) {
		//	throw new IOException("No appropriate writer found");
		//}
		//binaryImage = buffer.toByteArray();
		binaryImage = ((DirectBufferedImage)bufferedImage).getSrc();
		((DirectBufferedImage)bufferedImage).getInfo(info);
	}
	
	/**
	 * Reset the contents of this image to a new BufferedImage.
	 * If you do not want the BufferedImage anymore, call reset()
	 * 
	 * Only the marked image is serializable.
	 * 
	 * @param newBasis
	 * @throws IOException
	 */
	public void mark(BufferedImage bufferedImage) throws IOException {
		this.bufferedImage = bufferedImage;
		if (bufferedImage == null) {
			return;
		}
		_mark(bufferedImage);
	}
	
	/**
	 * @throws IOException 
	 * 
	 * Take the current Buffered Image state and make it the default
	 * Subsequent calls to reset() will lead to this state.
	 * 
	 * If you do not want the BufferedImage anymore, call reset().
	 * 
	 * Only the marked image is serializable.
	 *  
	 */
	public void mark() throws IOException {
		if (bufferedImage == null) {
			return;
		}
		else {
			_mark((BufferedImage)bufferedImage);
		}
	}
	
	public int getID() {
		return id;
	}
	
}