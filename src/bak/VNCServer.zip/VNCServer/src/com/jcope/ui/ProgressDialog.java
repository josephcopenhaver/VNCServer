package com.jcope.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JRootPane;


public class ProgressDialog extends JFrame {
	
	public static final long serialVersionUID = -1L;
	
	private static enum RESULT {DONE, CANCELLED, FAILED};
	
	Component parent;
	double progress = 0;
	boolean canCancel;
	Runnable updateHandler[] = {null};
	Color progressColor = Color.green;
	Runnable updateEvent = new Runnable() {
		public void run() {
			synchronized (updateHandler) {
				updateHandler[0] = null;
				repaint();
			}
		}
	};
	RESULT result = RESULT.FAILED;
	
	public ProgressDialog(Component parent, String title, boolean canCancel) {
		super(title);
		this.parent = parent;
		this.canCancel = canCancel;
	}
	
	public void setProgress(double progress) {
		if (progress < 0) {
			progress = 0;
		}
		else if (progress > 1) {
			progress = 1;
		}
		this.progress = progress;
		if (progress == 1) {
			result = RESULT.DONE;
			dispose();
		}
		synchronized (updateHandler) {
			if (updateHandler[0] != null) {
				updateHandler[0] = updateEvent;
				java.awt.EventQueue.invokeLater(updateEvent);
			}
		}
	}
	
	public void setVisible(boolean visible) {
		parent.setEnabled(!visible);
		if (visible && canCancel) {
			setUndecorated(true);
			getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		}
		super.setVisible(visible);
	}
	
	public void dispose() {
		if (result == RESULT.FAILED) {
			result = RESULT.CANCELLED;
		}
		setVisible(false);
		super.dispose();
	}
	
	public void repaint() {
		Dimension dim = getSize();
		Graphics d2 = getGraphics();
		d2.fillRect(0, 0, (int)(((double)dim.width) * progress), dim.height);
	}
	
	public RESULT getResult() {
		return result;
	}
	
}